// ==UserScript==
// @name         OGame Building Queue Manager
// @namespace    https://s181-pt.ogame.gameforge.com/
// @version      0.9.2
// @description  Gestor com iframe de execução isolado para impedir navegação da janela principal.
// @match        https://s181-pt.ogame.gameforge.com/game/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(() => {
  'use strict';

  // O gestor só é criado na janela principal; o executor oculto usa o DOM do jogo.
  if (window.top !== window.self) return;

  const VERSION = '0.9.3';
  const STORAGE_KEY = 'ogbqm_s181_v1';
  const ACCOUNT_INFO_URL = '/game/index.php?page=componentOnly&component=externaldataexport&action=accountInfo&asJson=1';
  const BUILDINGS = {
    1: 'Mina de Metal',
    2: 'Mina de Cristal',
    3: 'Sintetizador de Deutério',
    4: 'Planta de Energia Solar',
    12: 'Reator de Fusão',
    14: 'Fábrica de Robôs',
    15: 'Fábrica de Nanites',
    21: 'Hangar',
    22: 'Armazém de Metal',
    23: 'Armazém de Cristal',
    24: 'Depósito de Deutério',
    31: 'Laboratório de Pesquisas',
    33: 'Terra-Formador',
    34: 'Depósito da Aliança',
    36: 'Estaleiro Espacial',
    41: 'Base Lunar',
    42: 'Sensor Phalanx',
    43: 'Portal de Salto Quântico',
    44: 'Silo de Mísseis'
  };

  // Pesquisas convencionais (tecnologias globais da conta). As pesquisas de
  // formas de vida são específicas de cada planeta e ficam fora desta fila.
  const RESEARCHES = {
    106: { name: 'Tecnologia de Espionagem', field: 'EspionageTechnology', aliases: ['espionage', 'espionagetechnology'] },
    108: { name: 'Tecnologia de Computadores', field: 'ComputerTechnology', aliases: ['computer', 'computertechnology'] },
    109: { name: 'Tecnologia de Armas', field: 'WeaponsTechnology', aliases: ['weapons', 'weaponstechnology'] },
    110: { name: 'Tecnologia de Escudo', field: 'ShieldingTechnology', aliases: ['shielding', 'shieldingtechnology'] },
    111: { name: 'Tecnologia de Blindagem', field: 'ArmourTechnology', aliases: ['armour', 'armourtechnology', 'armor', 'armortechnology'] },
    113: { name: 'Tecnologia de Energia', field: 'EnergyTechnology', aliases: ['energy', 'energytechnology'] },
    114: { name: 'Tecnologia de Hiperespaço', field: 'HyperspaceTechnology', aliases: ['hyperspace', 'hyperspacetechnology'] },
    115: { name: 'Motor de Combustão', field: 'CombustionDrive', aliases: ['combustion', 'combustiondrive'] },
    117: { name: 'Motor de Impulsão', field: 'ImpulseDrive', aliases: ['impulse', 'impulsedrive'] },
    118: { name: 'Motor de Hiperespaço', field: 'HyperspaceDrive', aliases: ['hyperspacedrive'] },
    120: { name: 'Tecnologia Laser', field: 'LaserTechnology', aliases: ['laser', 'lasertechnology'] },
    121: { name: 'Tecnologia de Iões', field: 'IonTechnology', aliases: ['ion', 'iontechnology'] },
    122: { name: 'Tecnologia de Plasma', field: 'PlasmaTechnology', aliases: ['plasma', 'plasmatechnology'] },
    123: { name: 'Rede Intergaláctica de Pesquisas', field: 'IntergalacticResearchNetwork', aliases: ['intergalacticresearchnetwork', 'irn'] },
    124: { name: 'Astrofísica', field: 'Astrophysics', aliases: ['astrophysics'] },
    199: { name: 'Tecnologia de Gravitão', field: 'GravitonTechnology', aliases: ['graviton', 'gravitontechnology'] }
  };

  const DEFAULTS = {
    mode: 'manual',
    minimized: false,
    position: { right: 18, top: 90 },
    queue: [],
    researchQueue: [],
    activeBuildingLocks: [],
    selectedPlanetId: '',
    accountSnapshot: null,
    buildingSelections: {},
    researchSelections: {},
    activeResearchLock: null,
    activeTab: 'buildings',
    autoBuild: { active: false, currentQueueId: null, currentResearchQueueId: null, lastMessage: '', nextCheckAt: null, lastScanAt: null, resumeAfterNavigation: false, navigationTarget: null, manualNavigationHold: false, manualPlanetId: null, manualNavigationAt: null }
  };

  const clone = value => JSON.parse(JSON.stringify(value));
  const loadState = () => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      return {
        ...clone(DEFAULTS),
        ...(saved && typeof saved === 'object' ? saved : {}),
        position: { ...DEFAULTS.position, ...(saved?.position || {}) },
        queue: Array.isArray(saved?.queue) ? saved.queue : [],
        researchQueue: Array.isArray(saved?.researchQueue) ? saved.researchQueue : [],
        activeBuildingLocks: Array.isArray(saved?.activeBuildingLocks) ? saved.activeBuildingLocks : [],
        accountSnapshot: saved?.accountSnapshot && Array.isArray(saved.accountSnapshot.planets)
          ? saved.accountSnapshot : null,
        buildingSelections: saved?.buildingSelections && typeof saved.buildingSelections === 'object'
          ? saved.buildingSelections : {},
        researchSelections: saved?.researchSelections && typeof saved.researchSelections === 'object'
          ? saved.researchSelections : {},
        activeResearchLock: saved?.activeResearchLock && typeof saved.activeResearchLock === 'object' ? saved.activeResearchLock : null,
        activeTab: saved?.activeTab === 'research' ? 'research' : 'buildings',
        autoBuild: { ...DEFAULTS.autoBuild, ...(saved?.autoBuild || {}) }
      };
    } catch {
      return clone(DEFAULTS);
    }
  };

  let state = loadState();
  state.activeBuildingLocks ||= [];
  let drag = null;
  let readStatus = '';
  let readBusy = false;
  let autoBuildBusy = false;

  const save = () => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch (error) { console.warn('[OGame BQM] Não foi possível guardar os dados locais:', error); }
  };
  const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
  const asInt = value => {
    const number = Number(value);
    return Number.isFinite(number) ? Math.max(0, Math.floor(number)) : 0;
  };

  // Mantém a escolha de modo já guardada. Em modo Automático, um único comando
  // prepara a fila e inicia a execução; não existe uma segunda confirmação.
  state.autoBuild ||= clone(DEFAULTS.autoBuild);
  state.autoBuild.manualNavigationHold = false;
  state.autoBuild.resumeAfterNavigation = false;
  state.autoBuild.navigationTarget = null;

  // No modo automático podem ficar selecionados vários edifícios por planeta.
  // A execução continua limitada a uma construção ativa por planeta.
  function normalizeAutoSelections() {
    state.buildingSelections ||= {};
  }

  function getPagePlanetId() {
    const metaId = document.querySelector('meta[name="ogame-planet-id"]')?.getAttribute('content') || '';
    let queryId = '';
    try { queryId = new URL(location.href).searchParams.get('cp') || ''; } catch { /* URL ainda indisponível */ }
    return String(metaId || queryId || '');
  }

  // Este ID representa a escolha manual do utilizador. Não o substituímos
  // por mudanças de sessão provocadas por pedidos em segundo plano.
  state.autoBuild ||= {};
  state.autoBuild.manualPlanetId ||= String(getPagePlanetId() || '');

  function rememberManualPlanetId(planetId) {
    const id = String(planetId || '');
    if (!id) return;
    state.autoBuild.manualPlanetId = id;
    state.autoBuild.manualNavigationAt = Date.now();
    save();
  }

  // O seletor lateral de planetas/luas usa links com cp=. Capturamos a escolha
  // antes de a interface mudar, para que a restauração nunca force um destino antigo.
  document.addEventListener('click', event => {
    if (event.target?.closest?.('#ogbqm')) return;
    const link = event.target?.closest?.('a[href*="cp="]');
    if (!link) return;
    try {
      const id = new URL(link.getAttribute('href') || link.href, location.href).searchParams.get('cp');
      if (id) rememberManualPlanetId(id);
    } catch (_) { /* link não contém um URL válido */ }
  }, true);

  function getPagePlanetType() {
    const raw = (document.querySelector('meta[name="ogame-planet-type"]')?.getAttribute('content') || '').toLowerCase();
    return raw === 'moon' || raw === '3' ? 'moon' : 'planet';
  }

  function getPlanetListFromDom() {
    const byId = {};
    document.querySelectorAll('#planetList .smallplanet, .smallplanet').forEach(row => {
      const planetLink = row.querySelector('.planetlink');
      const moonLink = row.querySelector('.moonlink');
      const coords = (row.querySelector('.planet-koords')?.textContent || '').replace(/[\[\]()\s]/g, '').trim();
      const getCp = link => {
        if (!link) return '';
        try { return new URL(link.getAttribute('href') || '', location.href).searchParams.get('cp') || ''; }
        catch { return ''; }
      };
      const planetId = getCp(planetLink);
      const moonId = getCp(moonLink);
      const planetName = row.querySelector('.planet-name')?.textContent?.trim()
        || row.querySelector('.planetPic')?.getAttribute('alt') || 'Planeta';
      const moonName = moonLink?.querySelector('img')?.getAttribute('alt')
        || moonLink?.getAttribute('title') || 'Lua';

      if (planetId) byId[String(planetId)] = { id: String(planetId), name: planetName, coords, type: 'planet' };
      if (moonId) byId[String(moonId)] = { id: String(moonId), name: moonName, coords, type: 'moon' };
    });
    return byId;
  }

  function getCurrentPlanet() {
    const id = String(getPagePlanetId());
    const type = getPagePlanetType();
    const domPlanet = getPlanetListFromDom()[id];
    const savedPlanet = state.accountSnapshot?.planets?.find(planet => String(planet.id) === id);
    return {
      id,
      type,
      name: domPlanet?.name || savedPlanet?.name || (id ? `${type === 'moon' ? 'Lua' : 'Planeta'} ${id}` : 'Não identificado'),
      coords: domPlanet?.coords || savedPlanet?.coords || ''
    };
  }

  function normalizeAccountData(data) {
    if (!data || data.success === false || data.status === 'failure') {
      const detail = data?.errors?.map(error => error.message || error.error).filter(Boolean).join(', ');
      throw new Error(detail || 'O servidor não devolveu os dados da conta.');
    }
    if (!data.planets && !data.moons) {
      throw new Error('A resposta não contém planetas nem luas.');
    }

    const domPlanets = getPlanetListFromDom();
    const normalized = [];

    function addCelestials(collection, type) {
      const entries = Array.isArray(collection)
        ? collection.map((value, index) => [String(value?.id ?? index), value])
        : Object.entries(collection || {});

      for (const [key, raw] of entries) {
        if (!raw || typeof raw !== 'object') continue;
        const id = String(raw.id ?? key);
        if (!id || id === 'undefined') continue;

        const dom = domPlanets[id] || {};
        const coordParts = [raw.galaxy, raw.system, raw.position];
        const coords = coordParts.every(part => part !== undefined && part !== null)
          ? coordParts.join(':') : (raw.coords || dom.coords || '');
        const buildingsRaw = raw.buildings && typeof raw.buildings === 'object' ? raw.buildings : {};
        const buildings = {};
        for (const [buildingId, level] of Object.entries(buildingsRaw)) {
          if (/^\d+$/.test(buildingId)) buildings[buildingId] = asInt(level);
        }
        const resourcesRaw = raw.resources && typeof raw.resources === 'object' ? raw.resources : {};
        const resources = {
          metal: asInt(resourcesRaw.metal),
          crystal: asInt(resourcesRaw.crystal),
          deuterium: asInt(resourcesRaw.deuterium ?? resourcesRaw.deut)
        };

        normalized.push({
          id,
          type,
          name: dom.name || raw.name || `${type === 'moon' ? 'Lua' : 'Planeta'} ${coords ? `[${coords}]` : id}`,
          coords,
          buildings,
          resources,
          resourcesKnown: !!raw.resources && Number.isFinite(Number(resourcesRaw.metal))
            && Number.isFinite(Number(resourcesRaw.crystal))
            && Number.isFinite(Number(resourcesRaw.deuterium ?? resourcesRaw.deut))
        });
      }
    }

    addCelestials(data.planets, 'planet');
    addCelestials(data.moons, 'moon');
    normalized.sort((a, b) => {
      const ac = a.coords.split(':').map(Number);
      const bc = b.coords.split(':').map(Number);
      for (let i = 0; i < 3; i++) if ((ac[i] || 0) !== (bc[i] || 0)) return (ac[i] || 0) - (bc[i] || 0);
      return a.type.localeCompare(b.type);
    });
    return normalized;
  }

  function normalizeResearchLevelValue(value) {
    if (value && typeof value === 'object') {
      value = value.level ?? value.technologyLevel ?? value.amount ?? value.quantity ?? value.value;
    }
    const number = Number(value);
    return Number.isFinite(number) && number >= 0 ? Math.floor(number) : null;
  }

  function normalizeResearchLevels(data) {
    const candidates = [
      data?.researches, data?.research, data?.researchLevels, data?.playerResearches, data?.technologies,
      data?.player?.researches, data?.player?.research, data?.player?.researchLevels,
      data?.account?.researches, data?.account?.research, data?.account?.researchLevels,
      data?.playerData?.researches, data?.playerData?.research, data?.playerData?.researchLevels
    ].filter(value => value && typeof value === 'object');
    const result = {};

    for (const source of candidates) {
      const entries = Array.isArray(source)
        ? source.map(item => [String(item?.id ?? item?.technologyId ?? ''), item])
        : Object.entries(source);
      const normalizedEntries = entries.map(([key, value]) => [String(key).toLowerCase().replace(/[^a-z0-9]/g, ''), value]);
      for (const [id, definition] of Object.entries(RESEARCHES)) {
        if (result[id] !== undefined) continue;
        const aliases = [id, definition.field, ...definition.aliases]
          .map(value => String(value).toLowerCase().replace(/[^a-z0-9]/g, ''));
        const found = normalizedEntries.find(([key]) => aliases.includes(key));
        if (found) {
          const level = normalizeResearchLevelValue(found[1]);
          if (level !== null) result[id] = level;
        }
      }
    }

    // Algumas versões da interface não incluem os níveis no accountInfo. No
    // ecrã de pesquisas, o nível alvo no botão permite inferir o nível atual.
    const domLevels = readResearchLevelsFromDom();
    for (const [id, level] of Object.entries(domLevels)) {
      if (result[id] === undefined) result[id] = level;
    }
    return result;
  }

  function readResearchLevelsFromDom() {
    const result = {};
    for (const button of document.querySelectorAll('button.upgrade[data-technology]')) {
      const id = String(button.getAttribute('data-technology') || '');
      if (!RESEARCHES[id]) continue;
      const target = getButtonTargetLevel(button);
      if (Number.isInteger(target) && target > 0) result[id] = target - 1;
    }
    for (const card of document.querySelectorAll('.technology, [data-technology]')) {
      const id = String(card.getAttribute('data-technology') || '');
      if (!RESEARCHES[id] || result[id] !== undefined) continue;
      const levelNode = card.querySelector('.level, .technologyLevel, .researchLevel, [class*="level"]');
      const text = levelNode?.textContent || card.textContent || '';
      const match = text.match(/(?:nível|level)\s*[:#]?\s*(\d+)/i);
      if (match) result[id] = Number(match[1]);
    }
    return result;
  }

  async function readAccountData(options = {}) {
    const silent = Boolean(options.silent);
    if (readBusy) return false;
    readBusy = true;
    if (!silent) {
      readStatus = 'A consultar os dados da conta…';
      render();
    }

    let success = false;
    try {
      const response = await fetch(ACCOUNT_INFO_URL, {
        method: 'GET',
        cache: 'no-store',
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      const text = await response.text();
      let data;
      try { data = JSON.parse(text); }
      catch { throw new Error('O servidor não devolveu JSON. Confirma que estás autenticado no OGame S181.'); }
      if (!response.ok) throw new Error(`Erro HTTP ${response.status}.`);

      const planets = normalizeAccountData(data);
      if (!planets.length) throw new Error('Não encontrei planetas ou luas com IDs válidos.');

      const parsedResearches = normalizeResearchLevels(data);
      // accountInfo pode expor apenas parte dos campos de investigação; não
      // descartamos níveis já lidos no ecrã de Pesquisas quando a resposta
      // seguinte vier incompleta.
      const researches = {
        ...(state.accountSnapshot?.researches || {}),
        ...parsedResearches
      };
      state.accountSnapshot = { syncedAt: new Date().toISOString(), planets, researches };
      const validSelected = state.selectedPlanetId
        && planets.some(planet => String(planet.id) === String(state.selectedPlanetId));
      if (!validSelected) {
        const currentId = String(state.autoBuild?.manualPlanetId || getPagePlanetId());
        state.selectedPlanetId = planets.some(planet => String(planet.id) === currentId)
          ? currentId : String(planets[0].id);
      }
      save();
      const planetCount = planets.filter(planet => planet.type === 'planet').length;
      const moonCount = planets.filter(planet => planet.type === 'moon').length;
      readStatus = `Leitura concluída: ${planetCount} planetas e ${moonCount} luas.`;
      success = true;
    } catch (error) {
      console.error('[OGame BQM] Erro ao ler dados da conta:', error);
      readStatus = `Não foi possível ler os níveis: ${error.message || error}`;
    } finally {
      readBusy = false;
      render();
    }
    return success;
  }

  normalizeAutoSelections();
  save();


  const style = document.createElement('style');
  style.textContent = `
    #ogbqm { position:fixed; z-index:2147483000; top:${state.position.top}px; right:${state.position.right}px;
      width:370px; max-width:calc(100vw - 12px); max-height:calc(100vh - 8px); max-height:calc(100dvh - 8px);
      display:flex; flex-direction:column; overflow:hidden; color:#e8edf4; background:#17212e;
      border:1px solid #526477; border-radius:9px; box-shadow:0 8px 28px #0009;
      font:12px/1.35 Arial,sans-serif; }
    #ogbqm * { box-sizing:border-box; }
    #ogbqm .head { display:flex; align-items:center; justify-content:space-between; gap:8px;
      flex:0 0 auto; padding:6px 8px; background:#223247; cursor:move; }
    #ogbqm .brand { font-weight:700; letter-spacing:.1px; }
    #ogbqm button, #ogbqm input, #ogbqm select { font:inherit; }
    #ogbqm button { border:1px solid #60758b; color:#f5f7fa; background:#30465d; border-radius:5px;
      padding:5px 8px; cursor:pointer; }
    #ogbqm button:hover { background:#3d5874; }
    #ogbqm button:disabled { opacity:.45; cursor:not-allowed; }
    #ogbqm .body { padding:6px; display:grid; gap:5px; min-height:0; overflow-y:auto; overscroll-behavior:contain;
      max-height:calc(100vh - 45px); max-height:calc(100dvh - 45px); }
    #ogbqm .muted { color:#aebdca; font-size:10px; }
    #ogbqm .mode { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:5px 7px;
      background:#202f40; border-radius:6px; }
    #ogbqm .switch { position:relative; width:39px; height:21px; display:inline-block; flex:none; }
    #ogbqm .switch input { opacity:0; width:0; height:0; }
    #ogbqm .slider { position:absolute; inset:0; background:#68798a; border-radius:20px; cursor:pointer; transition:.2s; }
    #ogbqm .slider:before { content:""; position:absolute; width:15px; height:15px; left:3px; top:3px;
      background:white; border-radius:50%; transition:.2s; }
    #ogbqm .switch input:checked + .slider { background:#b07b2c; }
    #ogbqm .switch input:checked + .slider:before { transform:translateX(18px); }
    #ogbqm select { min-width:0; max-width:100%; color:#f4f7fa; background:#0f1924;
      border:1px solid #53687d; border-radius:5px; padding:5px 6px; }
    #ogbqm .section { padding:5px 6px; background:#202f40; border:1px solid #3b5065; border-radius:6px; display:grid; gap:4px; }
    #ogbqm .topline { display:flex; align-items:center; justify-content:space-between; gap:7px; }
    #ogbqm .planet-select { width:100%; }
    #ogbqm .tabs { display:flex; gap:5px; }
    #ogbqm .tabs button { flex:1; }
    #ogbqm .tabs button.active { background:#315b45; border-color:#568a69; font-weight:700; }
    #ogbqm .research-list { display:grid; gap:3px; max-height:210px; overflow-y:auto; padding-right:2px; }
    #ogbqm .research-row { display:grid; grid-template-columns:19px minmax(0,1fr) 38px 76px; align-items:center; gap:5px;
      padding:5px; border-radius:4px; background:#172635; }
    #ogbqm .research-row input[type=checkbox] { width:15px; height:15px; margin:0; accent-color:#59ad78; cursor:pointer; }
    #ogbqm .research-name { min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    #ogbqm .research-level { text-align:right; color:#b9e3c8; font-weight:700; font-variant-numeric:tabular-nums; }
    #ogbqm .notice { padding:6px 7px; border-radius:5px; background:#3a3020; color:#f2d7a8; font-size:10px; }
    #ogbqm .notice.good { background:#20392f; color:#bce8ce; }
    #ogbqm .notice.error { background:#492b2b; color:#ffd0d0; }
    #ogbqm .building-list { display:grid; gap:3px; max-height:195px; overflow-y:auto; padding-right:2px; }
    #ogbqm .building-row { display:grid; grid-template-columns:19px minmax(0,1fr) 42px 88px; align-items:center;
      gap:4px; padding:3px 4px; border-radius:4px; background:#172635; }
    #ogbqm .building-row:hover { background:#263b50; }
    #ogbqm .building-row input[type=checkbox] { width:15px; height:15px; margin:0; accent-color:#59ad78; cursor:pointer; }
    #ogbqm .building-name { min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    #ogbqm .current-level { text-align:right; color:#b9e3c8; font-weight:700; font-variant-numeric:tabular-nums; }
    #ogbqm .target-level { width:88px; padding:4px 3px !important; }
    #ogbqm .target-auto { width:88px; text-align:center; color:#bce8ce; font-weight:700; font-variant-numeric:tabular-nums; }
    #ogbqm .suggestions { display:grid; gap:5px; max-height:135px; overflow-y:auto; }
    #ogbqm .suggestion { padding:6px; background:#172635; border:1px solid #3b5065; border-radius:5px; font-size:10px; }
    #ogbqm .list-head { display:grid; grid-template-columns:19px minmax(0,1fr) 42px 88px; gap:5px; padding:0 5px;
      color:#9fb0c0; font-size:9px; text-transform:uppercase; }
    #ogbqm .primary { width:100%; background:#315b45; border-color:#568a69; font-weight:700; }
    #ogbqm .queue { display:grid; gap:4px; max-height:115px; overflow-y:auto; }
    #ogbqm .item { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:4px; padding:4px;
      background:#202f40; border:1px solid #3b5065; border-radius:6px; }
    #ogbqm .item.current { border-color:#c18a3c; }
    #ogbqm .item-title { font-weight:700; }
    #ogbqm .item-meta { color:#b7c5d2; font-size:10px; margin-top:2px; }
    #ogbqm .item-status { grid-column:1 / -1; font-size:10px; margin-top:2px; padding:3px 5px; border-radius:4px; }
    #ogbqm .item-status.ready { color:#bce8ce; background:#20392f; }
    #ogbqm .item-status.short { color:#f2d7a8; background:#3a3020; }
    #ogbqm .item-status.wait { color:#c7d2de; background:#283746; }
    #ogbqm .item-status.achieved { color:#bce8ce; background:#20392f; }
    #ogbqm .item-status.unknown { color:#ffd0d0; background:#492b2b; }
    #ogbqm .item-status.started { color:#bce8ce; background:#20392f; }
    #ogbqm .item-status.sent { color:#d7e4f2; background:#283746; }
    #ogbqm .analysis-summary { font-size:10px; padding:6px 7px; border-radius:5px; background:#20392f; color:#bce8ce; }
    #ogbqm .countdown-panel { display:flex; align-items:center; justify-content:space-between; gap:6px; padding:5px 7px;
      background:#172635; border:1px solid #3b5065; border-radius:5px; font-size:10px; }
    #ogbqm .countdown-panel strong { color:#bce8ce; font-size:13px; font-variant-numeric:tabular-nums; }
    #ogbqm .item-buttons { display:flex; flex-direction:row; align-items:center; gap:3px; }
    #ogbqm .item-buttons button { min-width:24px; padding:3px 5px; }
    #ogbqm .item-buttons button[data-action="cancel-order"] { color:#ffd6d6; border-color:#a65353; background:#512d35; font-weight:700; }
    #ogbqm .item-buttons button[data-action="cancel-order"]:hover { background:#713840; }
    #ogbqm .actions { display:flex; gap:5px; flex-wrap:wrap; }
    #ogbqm .actions button { padding:4px 6px; font-size:10px; }
    #ogbqm .footer { border-top:1px solid #3b5065; padding-top:5px; font-size:10px; color:#aebdca; }
    #ogbqm.min .body { display:none; }
    /* Compacta a interface em ecrãs de portátil: 1920x1080 a 125% costuma
       disponibilizar cerca de 864px de altura CSS. Mantém a letra legível. */
    @media (max-height:900px) {
      #ogbqm { width:350px; max-height:calc(100dvh - 8px); }
      #ogbqm .head { padding:5px 7px; }
      #ogbqm .body { padding:5px; gap:4px; max-height:calc(100dvh - 42px); }
      #ogbqm .mode { padding:4px 6px; }
      #ogbqm .section { padding:4px 5px; gap:3px; }
      #ogbqm .building-list { max-height:155px; }
      #ogbqm .research-list { max-height:155px; }
      #ogbqm .suggestions { max-height:105px; gap:3px; }
      #ogbqm .queue { max-height:95px; gap:3px; }
      #ogbqm .suggestion { padding:4px; }
      #ogbqm .item { padding:4px; gap:3px; }
      #ogbqm .item-meta, #ogbqm .item-status { margin-top:1px; }
      #ogbqm .countdown-panel { padding:4px 6px; }
      #ogbqm .notice { padding:4px 5px; }
      #ogbqm .footer { padding-top:3px; }
    }
    @media (max-width:420px) { #ogbqm { right:6px !important; width:calc(100vw - 12px); } }
  `;
  document.head.appendChild(style);

  const root = document.createElement('section');
  root.id = 'ogbqm';
  document.body.appendChild(root);

  function getDisplayedPlanet() {
    const list = state.accountSnapshot?.planets || [];
    const selectedId = String(state.selectedPlanetId || getPagePlanetId());
    return list.find(planet => String(planet.id) === selectedId) || null;
  }

  // Guarda o estado dos vistos e dos níveis antes de qualquer atualização visual.
  // O OGame atualiza elementos do <head> em segundo plano; sem esta cópia,
  // uma nova renderização repõe os vistos e parece que desaparecem sozinhos.
  function captureBuildingSelections() {
    const planet = getDisplayedPlanet();
    if (!planet) return;
    const list = root.querySelector('.building-list');
    // Durante a troca de planeta, o painel ainda pode conter as linhas antigas.
    // Só guardar quando o ID das linhas corresponder ao planeta apresentado.
    if (list && String(list.dataset.planetId || '') !== String(planet.id)) return;
    state.buildingSelections ||= {};
    const planetSelections = state.buildingSelections[String(planet.id)] ||= {};
    root.querySelectorAll('.building-row').forEach(row => {
      const buildingId = String(row.dataset.buildingId || '');
      if (!buildingId) return;
      const checkbox = row.querySelector('.building-check');
      const target = row.querySelector('.target-level');
      const targetLevel = Number(target?.value);
      const previous = planetSelections[buildingId] || {};
      planetSelections[buildingId] = {
        checked: checkbox ? checkbox.checked : Boolean(previous.checked),
        targetLevel: Number.isInteger(targetLevel) && targetLevel > 0
          ? targetLevel : previous.targetLevel
      };
    });
  }

  function renderBuildingChoices(planet) {
    if (!planet) return '<div class="muted">Carrega primeiro nos dados dos planetas.</div>';
    const entries = Object.entries(planet.buildings || {})
      .filter(([id]) => /^\d+$/.test(id))
      .sort((a, b) => Number(a[0]) - Number(b[0]));
    if (!entries.length) return '<div class="muted">Não foram encontrados edifícios neste astro.</div>';

    return entries.map(([id, rawLevel]) => {
      const level = asInt(rawLevel);
      const name = BUILDINGS[id] || `Edifício #${id}`;
      const savedSelection = state.buildingSelections?.[String(planet.id)]?.[String(id)] || {};
      const maxTarget = Math.min(999, Math.max(level + 1, level + 20));
      const savedTarget = Number(savedSelection.targetLevel);
      const selectedTarget = Number.isInteger(savedTarget) && savedTarget > level && savedTarget <= maxTarget
        ? savedTarget : level + 1;
      const targetControl = state.mode === 'auto'
        ? `<span class="target-auto" title="Próximo nível calculado automaticamente">${level} → ${level + 1}</span>`
        : `<select class="target-level" aria-label="Nível pretendido para ${esc(name)}">${Array.from({ length: maxTarget - level }, (_, index) => {
            const target = level + index + 1;
            return `<option value="${target}" ${target === selectedTarget ? 'selected' : ''}>Nível ${target}</option>`;
          }).join('')}</select>`;
      return `<label class="building-row" data-building-id="${esc(id)}" data-current-level="${level}">
        <input class="building-check" type="checkbox" ${savedSelection.checked ? 'checked' : ''} aria-label="Analisar ${esc(name)}">
        <span class="building-name" title="${esc(name)}">${esc(name)}</span>
        <span class="current-level" title="Nível atual">${level}</span>
        ${targetControl}
      </label>`;
    }).join('');
  }

  function getSelectedBuildingIds(planetId) {
    const selected = state.buildingSelections?.[String(planetId)] || {};
    const planet = getPlanetSnapshot(planetId);
    return Object.keys(selected)
      .filter(id => selected[id]?.checked && /^\d+$/.test(id)
        && (!planet || Object.prototype.hasOwnProperty.call(planet.buildings || {}, id)))
      .sort((a, b) => Number(a) - Number(b));
  }

  function getAutomaticBuildingSuggestions() {
    const planets = state.accountSnapshot?.planets || [];
    const suggestions = [];
    for (const planet of planets) {
      for (const buildingId of getSelectedBuildingIds(planet.id)) {
        const currentLevel = asInt(planet.buildings?.[buildingId]);
        const targetLevel = currentLevel + 1;
        const existing = state.queue.find(item =>
          !['done', 'cancelled'].includes(item.status)
          && String(item.planetId) === String(planet.id)
          && String(item.buildingId) === String(buildingId)
        );
        const inProgress = hasBuildingLock(planet.id, buildingId);
        suggestions.push({
          planet,
          buildingId,
          building: BUILDINGS[buildingId] || `Edifício #${buildingId}`,
          currentLevel,
          targetLevel,
          existing,
          inProgress
        });
      }
    }
    return suggestions;
  }

  function getResearchLevel(technologyId) {
    const value = state.accountSnapshot?.researches?.[String(technologyId)];
    return Number.isFinite(Number(value)) ? asInt(value) : null;
  }

  function captureResearchSelections() {
    state.researchSelections ||= {};
    root.querySelectorAll('.research-row').forEach(row => {
      const id = String(row.dataset.researchId || '');
      if (!RESEARCHES[id]) return;
      const previous = state.researchSelections[id] || {};
      state.researchSelections[id] = { checked: Boolean(row.querySelector('.research-check')?.checked ?? previous.checked) };
    });
  }

  function getSelectedResearchIds() {
    return Object.keys(state.researchSelections || {})
      .filter(id => RESEARCHES[id] && state.researchSelections[id]?.checked)
      .sort((a, b) => Number(a) - Number(b));
  }

  function renderResearchChoices() {
    const ids = Object.keys(RESEARCHES).sort((a, b) => Number(a) - Number(b));
    const knownCount = ids.filter(id => getResearchLevel(id) !== null).length;
    if (!knownCount) {
      return `<div class="notice">Ainda não consegui ler os níveis das pesquisas. A leitura automática tenta obtê-los do accountInfo; abre uma vez a página de Pesquisas do OGame para o gestor também ler os níveis dos botões.</div>`;
    }
    return ids.map(id => {
      const definition = RESEARCHES[id];
      const level = getResearchLevel(id);
      const selected = Boolean(state.researchSelections?.[id]?.checked);
      const active = state.researchQueue.find(item => String(item.technologyId) === id && !['done', 'cancelled'].includes(item.status));
      const target = level === null ? '?' : String(level + 1);
      return `<label class="research-row" data-research-id="${id}">
        <input class="research-check" type="checkbox" ${selected ? 'checked' : ''} ${level === null ? 'disabled' : ''} aria-label="Monitorizar ${esc(definition.name)}">
        <span class="research-name" title="${esc(definition.name)}">${esc(definition.name)}</span>
        <span class="research-level" title="Nível atual">${level === null ? '—' : level}</span>
        <span class="target-auto" title="Próximo nível">${level === null ? '—' : `→ ${target}`}</span>
      </label>`;
    }).join('');
  }

  function isActiveResearchItem(item) {
    return item && ['pending', 'sent', 'started'].includes(item.status) && Boolean(RESEARCHES[String(item.technologyId)]);
  }

  function reconcileAutomaticResearchQueue() {
    const researches = state.accountSnapshot?.researches || {};

    // O bloqueio guarda apenas a investigação que está realmente em curso;
    // não é um histórico de pesquisas concluídas.
    if (state.activeResearchLock) {
      const lockedLevel = normalizeResearchLevelValue(researches[String(state.activeResearchLock.technologyId)]);
      if (lockedLevel !== null && lockedLevel >= Number(state.activeResearchLock.targetLevel)) {
        state.activeResearchLock = null;
      }
    }

    for (let index = state.researchQueue.length - 1; index >= 0; index--) {
      const item = state.researchQueue[index];
      if (!isActiveResearchItem(item)) {
        state.researchQueue.splice(index, 1);
        continue;
      }

      const technologyId = String(item.technologyId);
      const actual = normalizeResearchLevelValue(researches[technologyId]);
      if (actual !== null && actual >= Number(item.targetLevel)) {
        // A pesquisa já terminou: retirar simplesmente da fila.
        state.researchQueue.splice(index, 1);
        continue;
      }

      if (item.status === 'pending' && !state.researchSelections?.[technologyId]?.checked) {
        state.researchQueue.splice(index, 1);
        continue;
      }

      // Migra ordens iniciadas nas versões anteriores para um bloqueio
      // transitório, fora da fila pendente.
      if (item.status === 'started' || (item.status === 'sent' && item.visualConfirmation)) {
        state.activeResearchLock = {
          technologyId,
          targetLevel: Number(item.targetLevel),
          research: item.research || RESEARCHES[technologyId]?.name || 'Pesquisa',
          sourcePlanetId: item.sourcePlanetId || '',
          sourcePlanet: item.sourcePlanet || '',
          startedAt: item.sentAt || item.lastAttemptAt || new Date().toISOString()
        };
        state.researchQueue.splice(index, 1);
      }
    }

    for (const id of getSelectedResearchIds()) {
      const level = getResearchLevel(id);
      if (level === null) continue;
      if (state.activeResearchLock && String(state.activeResearchLock.technologyId) === id) continue;
      const hasActive = state.researchQueue.some(item =>
        String(item.technologyId) === id && isActiveResearchItem(item)
      );
      if (hasActive) continue;
      state.researchQueue.push({
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        type: 'research',
        technologyId: id,
        research: RESEARCHES[id].name,
        currentLevel: level,
        targetLevel: level + 1,
        status: 'pending',
        autoGenerated: true,
        triedPlanets: [],
        createdAt: new Date().toISOString()
      });
    }
    save();
  }

  function getNextPendingResearch() {
    const active = state.researchQueue.find(item => item.status === 'sent' || item.status === 'started');
    if (active || state.activeResearchLock) return null; // Só pode existir uma investigação global em curso.
    return state.researchQueue
      .filter(item => item.status === 'pending')
      .filter(item => state.researchSelections?.[String(item.technologyId)]?.checked)
      .filter(item => !item.retryAfter || Number(item.retryAfter) <= Date.now())
      .sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || '')))[0] || null;
  }

  function renderResearchQueue() {
    const rows = state.researchQueue.filter(item => !['cancelled'].includes(item.status));
    if (!rows.length) return '<div class="muted">A fila de pesquisas está vazia.</div>';
    return rows.map((item, index) => {
      const status = item.status === 'done' ? 'Concluída'
        : item.status === 'started' ? 'Investigação iniciada'
        : item.status === 'sent' ? 'Pedido enviado — a confirmar'
        : item.retryAfter && Number(item.retryAfter) > Date.now() ? 'À espera de nova verificação'
        : 'Pendente';
      const cls = item.status === 'done' || item.status === 'started' ? 'started' : item.status === 'sent' ? 'sent' : 'wait';
      return `<div class="item">
        <div><div class="item-title">${index + 1}. ${esc(item.research || RESEARCHES[String(item.technologyId)]?.name || 'Pesquisa')} — nível ${Number(item.targetLevel)}</div>
          <div class="item-meta">Global · ${esc(status)}${Number.isInteger(item.currentLevel) ? ` · atual ${item.currentLevel}` : ''}${item.sourcePlanet ? ` · laboratório: ${esc(item.sourcePlanet)}` : ''}</div></div>
        <div class="item-buttons"><button data-action="research-up" data-id="${esc(item.id)}" ${index === 0 ? 'disabled' : ''} title="Mover para cima">↑</button>
          <button data-action="research-down" data-id="${esc(item.id)}" ${index === rows.length - 1 ? 'disabled' : ''} title="Mover para baixo">↓</button>
          <button data-action="cancel-research" data-id="${esc(item.id)}" title="Retirar da fila e desativar monitorização" aria-label="Cancelar ${esc(item.research || 'pesquisa')}">×</button></div>
        <div class="item-status ${cls}">${esc(status)}</div>
      </div>`;
    }).join('');
  }

  function formatCountdown(milliseconds) {
    const totalSeconds = Math.max(0, Math.ceil(milliseconds / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return minutes ? `${minutes}:${String(seconds).padStart(2, '0')}` : `${seconds}s`;
  }

  // Contador único, partilhado entre edifícios e pesquisas.
  // Em Manual mostra a próxima atualização de dados; em Automático mostra
  // a próxima verificação global das duas filas.
  function getAutoCountdownText() {
    if (state.autoBuild?.active) {
      const target = Number(state.autoBuild.nextCheckAt);
      if (Number.isFinite(target) && target > 0) return formatCountdown(target - Date.now());
      if (autoBuildBusy) return 'A verificar edifícios e pesquisas…';
      return 'A preparar verificação global…';
    }
    if (readBusy) return 'A atualizar dados da conta…';
    if (Number.isFinite(accountRefreshDueAt) && accountRefreshDueAt > 0) {
      return formatCountdown(accountRefreshDueAt - Date.now());
    }
    return 'A preparar atualização…';
  }

  function updateCountdownDisplay() {
    const node = root.querySelector('#ogbqm-countdown');
    if (node) node.textContent = getAutoCountdownText();
  }

  function renderAutomaticSuggestions() {
    const suggestions = getAutomaticBuildingSuggestions();
    if (!suggestions.length) {
      return '<div class="muted">Ainda não há edifícios selecionados. Escolhe os edifícios que queres acompanhar em cada planeta ou lua; a seleção fica guardada individualmente.</div>';
    }
    const cards = suggestions.map(item => {
      let status = 'Pronto para verificar no jogo';
      let cls = 'wait';
      if (item.inProgress) {
        status = 'Construção iniciada — fora da fila pendente'; cls = 'started';
      } else if (item.existing?.status === 'sent' || item.existing?.status === 'started') {
        status = 'Pedido enviado — aguarda confirmação'; cls = 'started';
      } else if (item.existing?.status === 'pending' && item.existing?.retryAfter > Date.now()) {
        status = 'A aguardar nova verificação no jogo'; cls = 'short';
      } else if (item.existing?.status === 'pending') {
        status = 'À espera de disponibilidade/recursos'; cls = 'wait';
      }
      return `<div class="suggestion">
        <div><strong>${esc(item.planet.name)}</strong> <span class="muted">${esc(item.planet.coords || '')}</span></div>
        <div>${esc(item.building)}: nível ${item.currentLevel} → <strong>${item.targetLevel}</strong></div>
        <div class="item-status ${cls}">${esc(status)}</div>
      </div>`;
    }).join('');
    const executionButton = state.autoBuild?.active
      ? `<button data-action="stop-auto-build">Parar monitorização</button>`
      : `<button class="primary" data-action="prepare-and-run">Iniciar monitorização automática</button>`;
    return `<div class="suggestions">${cards}</div>
      <div class="actions">${executionButton}</div>
      <div class="muted">As ordens são executadas num contexto oculto; o planeta aberto continua a ser elegível e a janela principal fica livre para navegação manual. Uma construção ativa por planeta.</div>
      ${state.autoBuild?.lastMessage ? `<div class="notice">${esc(state.autoBuild.lastMessage)}</div>` : ''}`;
  }

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const POLL_MIN_MS = 45000;
  const POLL_MAX_MS = 60000;
  let autoBuildTimer = null;
  let accountRefreshTimer = null;
  let accountRefreshDueAt = null;

  function randomPollDelay() {
    // Intervalo aleatório inclusivo: 45 000–60 000 ms.
    return Math.floor(POLL_MIN_MS + Math.random() * (POLL_MAX_MS - POLL_MIN_MS + 1));
  }

  // Nunca coexistem dois ciclos: em Manual atualiza a conta; em Automático,
  // uma única leitura alimenta as filas de edifícios e de pesquisas.
  function scheduleAccountRefresh() {
    if (accountRefreshTimer) clearTimeout(accountRefreshTimer);
    accountRefreshTimer = null;
    if (state.autoBuild?.active) {
      accountRefreshDueAt = null;
      return;
    }
    const wait = randomPollDelay();
    accountRefreshDueAt = Date.now() + wait;
    accountRefreshTimer = setTimeout(async () => {
      accountRefreshTimer = null;
      accountRefreshDueAt = null;
      if (state.autoBuild?.active) return;
      await readAccountData({ silent: true });
      scheduleAccountRefresh();
    }, wait);
  }

  // Constrói URLs limpos para o iframe. Não reutiliza nem altera a URL da
  // janela principal: a navegação manual do utilizador é sempre independente.
  function buildPageUrl(planetId, component = 'supplies') {
    const url = new URL('/game/index.php', location.origin);
    url.searchParams.set('page', 'ingame');
    url.searchParams.set('component', String(component || 'supplies'));
    url.searchParams.set('cp', String(planetId));
    return url.toString();
  }

  function researchPageUrl(planetId) {
    return buildPageUrl(planetId, 'research');
  }

  // Ações em segundo plano: o jogo é aberto num iframe same-origin fora da
  // área visível. Assim, a janela principal continua livre para navegação manual.
  let backgroundGameFrame = null;
  let backgroundFrameBusy = false;

  const BACKGROUND_FRAME_SANDBOX = 'allow-scripts allow-same-origin allow-forms';

  function normalizeBackgroundNavigationTargets(frame) {
    // Algumas páginas do jogo declaram target=_top/_parent em links, formulários
    // ou em <base>. Reescrevemos esses destinos para _self e deixamos ainda a
    // sandbox do iframe bloquear qualquer tentativa programática de navegar a janela principal.
    try {
      const doc = frame.contentDocument;
      if (!doc) return;
      doc.querySelectorAll('base[target]').forEach(base => {
        const target = (base.getAttribute('target') || '').toLowerCase();
        if (target === '_top' || target === '_parent') base.setAttribute('target', '_self');
      });
      doc.querySelectorAll('a[target], form[target]').forEach(element => {
        const target = (element.getAttribute('target') || '').toLowerCase();
        if (target === '_top' || target === '_parent') element.setAttribute('target', '_self');
      });
      if (!doc.__ogbqmTargetGuardInstalled) {
        const forceLocalTarget = event => {
          const element = event.target?.closest?.('a[target], form[target]');
          if (!element) return;
          const target = (element.getAttribute('target') || '').toLowerCase();
          if (target === '_top' || target === '_parent') element.setAttribute('target', '_self');
        };
        doc.addEventListener('click', forceLocalTarget, true);
        doc.addEventListener('submit', forceLocalTarget, true);
        Object.defineProperty(doc, '__ogbqmTargetGuardInstalled', { value: true, configurable: false });
      }
    } catch (error) {
      console.warn('[OGame BQM] Não foi possível normalizar destinos do iframe:', error);
    }
  }

  function getBackgroundGameFrame() {
    if (backgroundGameFrame?.isConnected) return backgroundGameFrame;
    const frame = document.createElement('iframe');
    frame.id = 'ogbqm-background-game-frame';
    frame.title = 'OGame gestor — execução em segundo plano';
    frame.setAttribute('aria-hidden', 'true');
    // Não incluir allow-top-navigation nem allow-top-navigation-by-user-activation:
    // mesmo que o jogo tente usar window.top.location, o browser bloqueia a saída
    // do iframe e preserva a página onde o utilizador está a navegar.
    frame.setAttribute('sandbox', BACKGROUND_FRAME_SANDBOX);
    frame.setAttribute('referrerpolicy', 'same-origin');
    frame.addEventListener('load', () => normalizeBackgroundNavigationTargets(frame));
    Object.assign(frame.style, {
      position: 'fixed', left: '-1400px', top: '0', width: '1280px', height: '900px',
      border: '0', opacity: '0', pointerEvents: 'none', zIndex: '-1'
    });
    document.body.appendChild(frame);
    backgroundGameFrame = frame;
    return frame;
  }

  function backgroundUrlMatches(frame, planetId, component) {
    try {
      const win = frame.contentWindow;
      const doc = frame.contentDocument;
      if (!win || !doc || win.location.origin !== location.origin) return false;
      const params = new URLSearchParams(win.location.search);
      const metaPlanet = doc.querySelector('meta[name="ogame-planet-id"]')?.getAttribute('content') || '';
      const actualPlanet = metaPlanet || params.get('cp') || '';
      return params.get('page') === 'ingame'
        && params.get('component') === component
        && String(actualPlanet) === String(planetId)
        && doc.readyState !== 'loading';
    } catch (_) {
      return false;
    }
  }

  // Função de validação ao nível do IIFE: tem de estar acessível tanto ao
  // executor de edifícios como ao executor de pesquisas.
  function isExecutionContextCurrent(context, planetId, component) {
    // Nunca aceitar document da janela principal como contexto de execução.
    // Mesmo quando o planeta aberto coincide com a ordem, a execução decorre
    // exclusivamente no iframe oculto para não interferir com a navegação.
    if (!context || context.visible || !context.frame) return false;
    return backgroundUrlMatches(context.frame, planetId, component);
  }

  async function loadBackgroundGamePage(planetId, component) {
    // Não há fast-path para a página visível. Todas as ordens, incluindo as do
    // planeta atualmente aberto, usam sempre o executor oculto.
    if (backgroundFrameBusy) throw new Error('O executor em segundo plano já está ocupado.');
    backgroundFrameBusy = true;
    try {
      const frame = getBackgroundGameFrame();
      if (!backgroundUrlMatches(frame, planetId, component)) {
        const url = component === 'research' ? researchPageUrl(planetId) : buildPageUrl(planetId, component);
        const loaded = new Promise((resolve, reject) => {
          const timeout = setTimeout(() => reject(new Error('Tempo esgotado ao abrir o contexto de execução em segundo plano.')), 20000);
          const onLoad = () => { clearTimeout(timeout); resolve(); };
          const onError = () => { clearTimeout(timeout); reject(new Error('O navegador ou o servidor não permitiu carregar o jogo em contexto oculto.')); };
          frame.addEventListener('load', onLoad, { once: true });
          frame.addEventListener('error', onError, { once: true });
          frame.src = url;
        });
        await loaded;
      }

      const deadline = Date.now() + 15000;
      while (Date.now() < deadline) {
        if (backgroundUrlMatches(frame, planetId, component)) {
          const doc = frame.contentDocument;
          if (doc?.body) {
            normalizeBackgroundNavigationTargets(frame);
            return { frame, doc, visible: false };
          }
        }
        await sleep(250);
      }
      throw new Error('A página do planeta não ficou disponível no executor oculto. A navegação visível não foi alterada.');
    } finally {
      backgroundFrameBusy = false;
    }
  }

  function getBackgroundFramePlanetId(frame) {
    try {
      const win = frame?.contentWindow;
      const doc = frame?.contentDocument;
      if (!win || !doc || win.location.origin !== location.origin) return '';
      const params = new URLSearchParams(win.location.search);
      return String(doc.querySelector('meta[name="ogame-planet-id"]')?.getAttribute('content')
        || params.get('cp') || '');
    } catch (_) {
      return '';
    }
  }

  // OGame pode persistir no lado do servidor o último cp usado num contexto
  // oculto. No fim de cada operação, repõe no executor o planeta que o
  // utilizador tem efetivamente aberto na janela principal. Se o utilizador
  // mudar de planeta durante a operação, voltamos a ler o ID atual antes de
  // restaurar para não impor um destino antigo.
  async function restoreVisiblePlanetInBackground() {
    if (!backgroundGameFrame?.isConnected) return true;
    for (let attempt = 0; attempt < 3; attempt++) {
      const visiblePlanetId = String(state.autoBuild?.manualPlanetId || getPagePlanetId() || state.lastObservedPagePlanetId || '');
      if (!visiblePlanetId) return false;
      if (getBackgroundFramePlanetId(backgroundGameFrame) === visiblePlanetId) return true;
      try {
        await loadBackgroundGamePage(visiblePlanetId, 'overview');
        const currentVisibleId = String(state.autoBuild?.manualPlanetId || getPagePlanetId() || state.lastObservedPagePlanetId || '');
        if (getBackgroundFramePlanetId(backgroundGameFrame) === currentVisibleId) return true;
      } catch (error) {
        if (attempt === 2) {
          console.warn('[OGame BQM] Não foi possível repor o planeta ativo na sessão:', error);
          state.autoBuild.lastMessage = `Aviso: não consegui repor o planeta aberto após a tarefa em segundo plano (${error?.message || error}).`;
          save();
          render();
          return false;
        }
        await sleep(250);
      }
    }
    return false;
  }

  function getResearchUpgradeButton(technologyId, doc = document) {
    return doc.querySelector(`button.upgrade[data-technology="${CSS.escape(String(technologyId))}"]`);
  }

  function getResearchLabCandidates(item) {
    const tried = new Set((item.triedPlanets || []).map(String));
    const currentId = String(state.autoBuild?.manualPlanetId || getPagePlanetId());
    const candidates = (state.accountSnapshot?.planets || [])
      .filter(planet => asInt(planet.buildings?.['31']) > 0)
      .sort((a, b) => {
        // O planeta aberto é um destino elegível e preferido quando tem laboratório.
        // Caso contrário, usa o laboratório de nível mais elevado.
        if (String(a.id) === currentId) return -1;
        if (String(b.id) === currentId) return 1;
        const labDiff = asInt(b.buildings?.['31']) - asInt(a.buildings?.['31']);
        if (labDiff) return labDiff;
        const aTotal = asInt(a.resources?.metal) + asInt(a.resources?.crystal) + asInt(a.resources?.deuterium);
        const bTotal = asInt(b.resources?.metal) + asInt(b.resources?.crystal) + asInt(b.resources?.deuterium);
        return bTotal - aTotal;
      });
    const available = candidates.filter(planet => !tried.has(String(planet.id)));
    return available;
  }

  async function runAutoResearchOnceInternal() {
    reconcileAutomaticResearchQueue();
    if (state.activeResearchLock) return false;
    const inProgress = state.researchQueue.find(item => item.status === 'sent' || item.status === 'started');
    if (inProgress) return false;
    const item = state.researchQueue.find(entry => entry.id === state.autoBuild.currentResearchQueueId
      && entry.status === 'pending' && state.researchSelections?.[String(entry.technologyId)]?.checked
      && (!entry.retryAfter || Number(entry.retryAfter) <= Date.now())) || getNextPendingResearch();
    if (!item) return false;

    const candidates = getResearchLabCandidates(item);
    if (!candidates.length) {
      const hasAnyLab = (state.accountSnapshot?.planets || []).some(planet => asInt(planet.buildings?.['31']) > 0);
      item.triedPlanets = [];
      item.retryAfter = Date.now() + POLL_MIN_MS;
      state.autoBuild.lastMessage = hasAnyLab
        ? 'Nenhum laboratório ficou acessível no executor em segundo plano; vou voltar a tentar no próximo ciclo.'
        : 'Não encontrei nenhum planeta com Laboratório de Pesquisas para iniciar a próxima investigação.';
      save();
      return false;
    }

    let selectedContext = null;
    let selectedPlanet = null;
    let selectedButton = null;
    const expectedTarget = Number(item.targetLevel);
    for (const planet of candidates) {
      try {
        const context = await loadBackgroundGamePage(planet.id, 'research');
        let button = null;
        const deadline = Date.now() + 10000;
        while (Date.now() < deadline) {
          if (!state.autoBuild.active) return true;
          button = getResearchUpgradeButton(item.technologyId, context.doc);
          if (button) break;
          await sleep(250);
        }
        if (!button) {
          item.triedPlanets ||= [];
          if (!item.triedPlanets.includes(String(planet.id))) item.triedPlanets.push(String(planet.id));
          continue;
        }
        const actualTarget = getButtonTargetLevel(button);
        if (actualTarget !== expectedTarget) {
          item.triedPlanets ||= [];
          if (!item.triedPlanets.includes(String(planet.id))) item.triedPlanets.push(String(planet.id));
          continue;
        }
        if (button.disabled || button.getAttribute('aria-disabled') === 'true' || button.classList.contains('disabled')) {
          item.triedPlanets ||= [];
          if (!item.triedPlanets.includes(String(planet.id))) item.triedPlanets.push(String(planet.id));
          continue;
        }
        selectedContext = context;
        selectedPlanet = planet;
        selectedButton = button;
        break;
      } catch (error) {
        item.lastBackgroundError = error?.message || String(error);
      }
    }

    if (!selectedContext || !selectedButton || !selectedPlanet) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      state.autoBuild.currentResearchQueueId = null;
      state.autoBuild.lastMessage = item.lastBackgroundError
        ? `Não consegui carregar o laboratório em segundo plano (${item.lastBackgroundError}). A navegação manual ficou intacta.`
        : `Não encontrei um botão válido para ${item.research}, nível ${expectedTarget}, nos laboratórios disponíveis.`;
      save();
      return false;
    }

    if (!state.researchSelections?.[String(item.technologyId)]?.checked) {
      item.status = 'cancelled';
      state.autoBuild.currentResearchQueueId = null;
      state.autoBuild.lastMessage = `${item.research} foi retirada da seleção; sem iniciar investigação.`;
      save();
      return false;
    }

    const doc = selectedContext.doc;
    if (!isExecutionContextCurrent(selectedContext, selectedPlanet.id, 'research')) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      state.autoBuild.currentResearchQueueId = null;
      state.autoBuild.lastMessage = 'O contexto do laboratório mudou antes do envio; não iniciei a pesquisa. A navegação manual ficou intacta.';
      save();
      scheduleNextAutoCheck(null, null);
      return false;
    }
    const beforeCard = (selectedButton.closest('.technology') || selectedButton.parentElement)?.outerHTML || '';
    const beforeResearch = doc.querySelector('.researchQueue, .researchqueue, #researchQueue, .research.active')?.textContent || '';
    item.status = 'sent';
    item.sentAt = new Date().toISOString();
    item.sourcePlanetId = String(selectedPlanet.id);
    item.sourcePlanet = selectedPlanet.name;
    item.visualConfirmation = false;
    item.retryAfter = null;
    state.autoBuild.currentResearchQueueId = null;
    state.autoBuild.lastMessage = `A submeter ${item.research}, nível ${expectedTarget}, em segundo plano no laboratório de ${selectedPlanet.name}…`;
    save();
    render();
    selectedButton.click();
    await sleep(1800);

    const afterDoc = selectedContext.frame?.contentDocument || doc;
    const buttonAfter = getResearchUpgradeButton(item.technologyId, afterDoc);
    const afterCard = (buttonAfter?.closest('.technology') || buttonAfter?.parentElement)?.outerHTML || '';
    const afterResearch = afterDoc.querySelector('.researchQueue, .researchqueue, #researchQueue, .research.active')?.textContent || '';
    const confirmed = !buttonAfter || buttonAfter.disabled || getButtonTargetLevel(buttonAfter) !== expectedTarget
      || (beforeCard && afterCard && beforeCard !== afterCard)
      || (beforeResearch && afterResearch && beforeResearch !== afterResearch);
    item.visualConfirmation = Boolean(confirmed);
    item.lastAttemptAt = new Date().toISOString();
    if (confirmed) {
      state.activeResearchLock = {
        technologyId: String(item.technologyId),
        targetLevel: expectedTarget,
        research: item.research,
        sourcePlanetId: String(selectedPlanet.id),
        sourcePlanet: selectedPlanet.name,
        startedAt: item.sentAt
      };
      // A tarefa deixa a fila assim que o jogo confirma o início.
      state.researchQueue = state.researchQueue.filter(entry => entry.id !== item.id);

      // Desmarcar também a seleção persistida para impedir que a reconciliação
      // volte a criar automaticamente esta mesma ordem no ciclo seguinte.
      const technologyId = String(item.technologyId);
      state.researchSelections ||= {};
      state.researchSelections[technologyId] ||= {};
      state.researchSelections[technologyId].checked = false;

      // Se o separador de pesquisas estiver visível, atualizar o checkbox antes
      // de render(), que começa por capturar novamente as seleções do DOM.
      const researchRow = [...root.querySelectorAll('.research-row')]
        .find(row => String(row.dataset.researchId || '') === technologyId);
      const researchCheckbox = researchRow?.querySelector('.research-check');
      if (researchCheckbox) researchCheckbox.checked = false;

      state.autoBuild.lastMessage = `${item.research}, nível ${expectedTarget}: iniciada; removida da fila pendente.`;
    } else {
      item.status = 'sent';
      state.autoBuild.lastMessage = `${item.research}, nível ${expectedTarget}: pedido enviado; mantenho na fila até confirmar o início.`;
    }
    save();
    render();
    scheduleNextAutoCheck('Verificação concluída; continuo a monitorizar as duas filas.', null);
    return true;
  }

  async function runAutoResearchOnce() {
    try {
      return await runAutoResearchOnceInternal();
    } finally {
      await restoreVisiblePlanetInBackground();
    }
  }

  // Edifícios de recursos/armazéns usam supplies; instalações usam facilities.
  // Sem esta distinção, o executor nunca encontra Robótica/Base Lunar na lua.
  function getBuildingComponent(buildingId) {
    const resourceBuildings = new Set(['1', '2', '3', '4', '12', '22', '23', '24']);
    return resourceBuildings.has(String(buildingId)) ? 'supplies' : 'facilities';
  }

  function getUpgradeButton(buildingId, doc = document) {
    return doc.querySelector(`button.upgrade[data-technology="${CSS.escape(String(buildingId))}"]`);
  }

  function getButtonTargetLevel(button) {
    const label = `${button?.getAttribute('aria-label') || ''} ${button?.getAttribute('data-tooltip-title') || ''}`;
    const match = label.match(/(?:nível|level)\s+(\d+)/i);
    return match ? Number(match[1]) : null;
  }

  function isSelectedBuilding(planetId, buildingId) {
    return getSelectedBuildingIds(planetId).includes(String(buildingId));
  }

  function isActiveQueueItem(item) {
    return item && ['pending', 'sent', 'started'].includes(item.status)
      && /^\d+$/.test(String(item.buildingId || ''));
  }

  function getPlanetSnapshot(planetId) {
    return state.accountSnapshot?.planets?.find(planet => String(planet.id) === String(planetId)) || null;
  }

  function hasBuildingLock(planetId, buildingId) {
    return (state.activeBuildingLocks || []).some(lock =>
      String(lock.planetId) === String(planetId)
      && String(lock.buildingId) === String(buildingId)
    );
  }

  function addBuildingLock(item) {
    state.activeBuildingLocks ||= [];
    const exists = state.activeBuildingLocks.some(lock =>
      String(lock.planetId) === String(item.planetId)
      && String(lock.buildingId) === String(item.buildingId)
      && Number(lock.targetLevel) === Number(item.targetLevel)
    );
    if (!exists) {
      state.activeBuildingLocks.push({
        planetId: String(item.planetId),
        buildingId: String(item.buildingId),
        building: item.building,
        planet: item.planet,
        targetLevel: Number(item.targetLevel),
        startedAt: item.sentAt || item.lastAttemptAt || new Date().toISOString()
      });
    }
  }

  // A fila mostra apenas tarefas por iniciar. Uma construção confirmada passa
  // para um bloqueio transitório até o nível subir; não guardamos histórico.
  function reconcileAutomaticQueue() {
    const planets = state.accountSnapshot?.planets || [];
    if (!planets.length) return;
    state.activeBuildingLocks ||= [];

    // Libertar bloqueios quando a leitura da conta já mostra o nível concluído.
    state.activeBuildingLocks = state.activeBuildingLocks.filter(lock => {
      const planet = getPlanetSnapshot(lock.planetId);
      if (!planet) return true;
      const actualLevel = asInt(planet.buildings?.[String(lock.buildingId)]);
      return actualLevel < Number(lock.targetLevel);
    });

    // Limpar ordens concluídas/canceladas e migrar inícios confirmados antigos.
    for (let index = state.queue.length - 1; index >= 0; index--) {
      const item = state.queue[index];
      if (!isActiveQueueItem(item)) {
        state.queue.splice(index, 1);
        continue;
      }
      const planet = getPlanetSnapshot(item.planetId);
      const actualLevel = planet ? asInt(planet.buildings?.[String(item.buildingId)]) : null;
      if (actualLevel !== null && actualLevel >= Number(item.targetLevel)) {
        state.queue.splice(index, 1);
        continue;
      }
      if (item.status === 'pending' && !isSelectedBuilding(item.planetId, item.buildingId)) {
        state.queue.splice(index, 1);
        continue;
      }
      if (item.status === 'started' || (item.status === 'sent' && item.visualConfirmation)) {
        addBuildingLock(item);
        state.queue.splice(index, 1);
      }
    }

    // Criar tarefas pendentes para todas as seleções. Se o mesmo edifício já
    // está em construção, só se cria o próximo nível depois de terminar.
    for (const planet of planets) {
      for (const buildingId of getSelectedBuildingIds(planet.id)) {
        const hasInFlightSameBuilding = hasBuildingLock(planet.id, buildingId);
        const hasQueuedOrder = state.queue.some(item =>
          String(item.planetId) === String(planet.id)
          && String(item.buildingId) === String(buildingId)
          && isActiveQueueItem(item)
        );
        if (hasInFlightSameBuilding || hasQueuedOrder) continue;
        const currentLevel = asInt(planet.buildings?.[buildingId]);
        state.queue.push({
          id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
          building: BUILDINGS[buildingId] || `Edifício #${buildingId}`,
          planet: planet.name,
          planetId: String(planet.id),
          buildingId: String(buildingId),
          currentLevel,
          targetLevel: currentLevel + 1,
          status: 'pending',
          autoGenerated: true,
          createdAt: new Date().toISOString()
        });
      }
    }
    save();
  }

  function findReadyQueueItems() {
    const planets = state.accountSnapshot?.planets || [];
    const planetsAlreadyBuilding = new Set([
      ...(state.queue || []).filter(item => item.status === 'sent' || item.status === 'started').map(item => String(item.planetId)),
      ...(state.activeBuildingLocks || []).map(lock => String(lock.planetId))
    ]);
    const pending = state.queue.filter(item => item.status === 'pending')
      .filter(item => isSelectedBuilding(item.planetId, item.buildingId))
      .filter(item => !item.retryAfter || Number(item.retryAfter) <= Date.now())
      .filter(item => !planetsAlreadyBuilding.has(String(item.planetId)))
      .sort((a, b) => {
        // O planeta aberto tem prioridade, mas todos os outros também são
        // tratados no mesmo ciclo global, cada um no seu contexto oculto.
        const currentId = String(state.autoBuild?.manualPlanetId || getPagePlanetId());
        const aCurrent = String(a.planetId) === currentId;
        const bCurrent = String(b.planetId) === currentId;
        if (aCurrent !== bCurrent) return aCurrent ? -1 : 1;
        const pa = planets.findIndex(planet => String(planet.id) === String(a.planetId));
        const pb = planets.findIndex(planet => String(planet.id) === String(b.planetId));
        if (pa !== pb) return pa - pb;
        return String(a.createdAt || '').localeCompare(String(b.createdAt || ''));
      });

    // Uma construção por planeta, mas não apenas uma construção por ciclo.
    const seenPlanets = new Set();
    return pending.filter(item => {
      const planetId = String(item.planetId);
      if (seenPlanets.has(planetId)) return false;
      seenPlanets.add(planetId);
      return true;
    });
  }

  function scheduleNextAttemptAfterSkip(message) {
    // Mesmo quando há outras ordens, aguarda pelo próximo ciclo partilhado.
    scheduleNextAutoCheck(message);
  }

  function scheduleNextAutoCheck(message) {
    if (autoBuildTimer) clearTimeout(autoBuildTimer);
    if (!state.autoBuild?.active) return;
    // Todas as verificações automáticas respeitam 45–60 segundos aleatórios.
    const wait = randomPollDelay();
    state.autoBuild.nextCheckAt = Date.now() + wait;
    if (message) state.autoBuild.lastMessage = `${message} Próxima verificação em cerca de ${Math.round(wait / 1000)} s.`;
    save();
    render();
    autoBuildTimer = setTimeout(() => {
      autoBuildTimer = null;
      state.autoBuild.nextCheckAt = null;
      runAutoBuild();
    }, wait);
  }

  function stopAutoBuild(message) {
    if (autoBuildTimer) clearTimeout(autoBuildTimer);
    autoBuildTimer = null;
    state.autoBuild.active = false;
    state.autoBuild.currentQueueId = null;
    state.autoBuild.currentResearchQueueId = null;
    state.autoBuild.nextCheckAt = null;
    accountRefreshDueAt = null;
    state.autoBuild.resumeAfterNavigation = false;
    state.autoBuild.navigationTarget = null;
    state.autoBuild.manualNavigationHold = false;
    state.autoBuild.lastMessage = message;
    save();
    render();
    scheduleAccountRefresh();
  }

  async function tryStartBuildingItemInternal(item) {
    const planet = getPlanetSnapshot(item.planetId);
    if (!planet || !Object.prototype.hasOwnProperty.call(planet.buildings || {}, String(item.buildingId))) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      return { started: false, message: `Sem dados de ${item.building} em ${item.planet}.` };
    }

    let context;
    try {
      // Cada planeta é aberto sequencialmente no iframe oculto. A janela
      // principal permanece livre e não há espera de 45–60 s entre planetas.
      context = await loadBackgroundGamePage(item.planetId, getBuildingComponent(item.buildingId));
    } catch (error) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      item.lastBackgroundError = error?.message || String(error);
      return { started: false, message: `Não consegui abrir ${item.planet} em segundo plano (${item.lastBackgroundError}).` };
    }

    let button = null;
    const deadline = Date.now() + 12000;
    while (Date.now() < deadline) {
      if (!state.autoBuild.active) return { started: false, stopped: true };
      button = getUpgradeButton(item.buildingId, context.doc);
      if (button) break;
      await sleep(250);
    }
    if (!button) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      return { started: false, message: `Não encontrei o botão de ${item.building} em ${item.planet}.` };
    }

    const expectedTarget = Number(item.targetLevel);
    const actualButtonTarget = getButtonTargetLevel(button);
    if (actualButtonTarget !== expectedTarget) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      return { started: false, message: `${item.building} em ${item.planet}: o botão indica nível ${actualButtonTarget ?? 'desconhecido'}, não ${expectedTarget}.` };
    }
    if (button.disabled || button.getAttribute('aria-disabled') === 'true' || button.classList.contains('disabled')) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      return { started: false, message: `${item.building} em ${item.planet}: botão indisponível (recursos ou requisitos).` };
    }
    if (!isSelectedBuilding(item.planetId, item.buildingId)) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      return { started: false, message: `${item.building} em ${item.planet}: seleção já desativada.` };
    }
    if (!isExecutionContextCurrent(context, item.planetId, getBuildingComponent(item.buildingId))) {
      item.retryAfter = Date.now() + POLL_MIN_MS;
      return { started: false, message: `O contexto de ${item.planet} mudou antes do envio; sem clique.` };
    }

    const technologyCard = button.closest('li.technology') || button.parentElement;
    const beforeCard = technologyCard?.outerHTML || '';
    const beforeQueue = context.doc.querySelector('#buildingqueue, #buildingQueue, .buildingQueue, .construction.active')?.textContent || '';
    if (!state.autoBuild.active) return { started: false, stopped: true };

    item.status = 'sent';
    item.sentAt = new Date().toISOString();
    item.visualConfirmation = false;
    item.retryAfter = null;
    state.autoBuild.currentQueueId = item.id;
    state.autoBuild.lastMessage = `A submeter ${item.building} nível ${expectedTarget} em ${item.planet}…`;
    save();
    render();
    button.click();
    await sleep(1800);

    const afterDoc = context.frame?.contentDocument || context.doc;
    const buttonAfter = getUpgradeButton(item.buildingId, afterDoc);
    const afterCard = (buttonAfter?.closest('li.technology') || buttonAfter?.parentElement)?.outerHTML || '';
    const afterQueue = afterDoc.querySelector('#buildingqueue, #buildingQueue, .buildingQueue, .construction.active')?.textContent || '';
    const visuallyConfirmed = !buttonAfter || buttonAfter.disabled
      || getButtonTargetLevel(buttonAfter) !== expectedTarget
      || (afterCard && beforeCard && afterCard !== beforeCard)
      || (afterQueue && afterQueue !== beforeQueue);
    item.visualConfirmation = Boolean(visuallyConfirmed);
    item.lastAttemptAt = new Date().toISOString();
    state.autoBuild.currentQueueId = null;
    if (visuallyConfirmed) {
      addBuildingLock(item);
      // A tarefa sai imediatamente da fila pendente; o bloqueio transitório
      // impede tentativas duplicadas até o nível novo aparecer nos dados.
      state.queue = state.queue.filter(entry => entry.id !== item.id);

      // Desmarcar a seleção persistida para impedir que reconcileAutomaticQueue()
      // volte a criar automaticamente esta mesma ordem no ciclo seguinte.
      state.buildingSelections ||= {};
      const planetSelections =
        state.buildingSelections[String(item.planetId)] ||= {};
      const buildingSelection =
        planetSelections[String(item.buildingId)] ||= {};
      buildingSelection.checked = false;

      // render() captura primeiro os checkboxes visíveis; por isso também
      // retiramos o visto do DOM antes de redesenhar o painel.
      const visibleList = root.querySelector('.building-list');
      if (visibleList &&
          String(visibleList.dataset.planetId || '') === String(item.planetId)) {
        const row = [...visibleList.querySelectorAll('.building-row')]
          .find(element =>
            String(element.dataset.buildingId || '') === String(item.buildingId)
          );
        const checkbox = row?.querySelector('.building-check');
        if (checkbox) checkbox.checked = false;
      }
    } else {
      item.status = 'sent';
    }
    save();
    render();
    return {
      started: Boolean(visuallyConfirmed),
      submitted: true,
      confirmed: Boolean(visuallyConfirmed),
      message: `${item.building} nível ${expectedTarget} em ${item.planet}: ${visuallyConfirmed ? 'iniciada e removida da fila pendente' : 'pedido enviado; mantém-se na fila até confirmação'}.`
    };
  }

  async function tryStartBuildingItem(item) {
    try {
      return await tryStartBuildingItemInternal(item);
    } finally {
      await restoreVisiblePlanetInBackground();
    }
  }

  async function runAutoBuild(options = {}) {
    if (autoBuildBusy || !state.autoBuild?.active || state.mode !== 'auto') return;
    autoBuildBusy = true;
    try {
      const canResumeSnapshot = Boolean(options.skipRefresh && state.accountSnapshot?.planets?.length);
      const refreshed = canResumeSnapshot || await readAccountData({ silent: true });
      if (!refreshed) {
        scheduleNextAutoCheck('Não foi possível atualizar os dados da conta; vou tentar novamente.', null);
        return;
      }
      state.autoBuild.lastScanAt = new Date().toISOString();
      reconcileAutomaticQueue();
      reconcileAutomaticResearchQueue();

      // Recolhe todas as ordens prontas, uma por planeta. O código percorre-as
      // sequencialmente no iframe oculto dentro deste mesmo ciclo de 45–60 s.
      const readyItems = findReadyQueueItems();
      const outcomes = [];
      let startedCount = 0;
      for (const item of readyItems) {
        if (!state.autoBuild.active || state.mode !== 'auto') break;
        try {
          const result = await tryStartBuildingItem(item);
          if (result.started) startedCount++;
          if (result.message) outcomes.push(result.message);
          if (result.stopped) break;
        } catch (error) {
          item.retryAfter = Date.now() + POLL_MIN_MS;
          outcomes.push(`Erro em ${item.planet}: ${error?.message || error}`);
        }
      }
      state.autoBuild.currentQueueId = null;
      save();

      // A pesquisa é global: no máximo uma investigação pode ser iniciada.
      const researchHandled = await runAutoResearchOnce();
      if (researchHandled) return;
      // Defesa adicional: garante que a sessão termina no planeta que o
      // utilizador deixou aberto, mesmo após várias ordens no mesmo ciclo.
      await restoreVisiblePlanetInBackground();

      const selectedCount = (state.accountSnapshot?.planets || []).reduce((total, planet) =>
        total + getSelectedBuildingIds(planet.id).length, 0);
      const selectedResearchCount = getSelectedResearchIds().length;
      const activeResearch = state.researchQueue.find(entry => entry.status === 'sent' || entry.status === 'started') || state.activeResearchLock;
      let message;
      if (startedCount > 0) {
        message = `Ciclo concluído: ${startedCount} construção(ões) submetida(s) em planetas distintos.`;
        if (outcomes.length > startedCount) message += ` ${outcomes.filter(Boolean).join(' ')}`;
      } else if (outcomes.length) {
        message = `Verifiquei ${readyItems.length} planeta(s), mas não iniciei novas construções. ${outcomes.join(' ')}`;
      } else if (activeResearch) {
        message = `${activeResearch.research} nível ${activeResearch.targetLevel} está em investigação; a fila global aguarda a conclusão.`;
      } else {
        message = (selectedCount || selectedResearchCount)
          ? `Verificados ${selectedCount} edifício(s) e ${selectedResearchCount} pesquisa(s); as restantes ordens aguardam recursos, disponibilidade ou conclusão de outra tarefa.`
          : 'Monitorização ativa, mas ainda não há edifícios ou pesquisas selecionados.';
      }
      scheduleNextAutoCheck(message, null);
    } catch (error) {
      console.error('[OGame BQM] Erro no ciclo automático:', error);
      scheduleNextAutoCheck(`Erro no ciclo automático: ${error?.message || error}. Vou tentar novamente.`, null);
    } finally {
      autoBuildBusy = false;
    }
  }

  function startAutoBuild() {
    if (state.mode !== 'auto') {
      alert('Ativa primeiro o modo Automático.');
      return;
    }
    const selectedCount = (state.accountSnapshot?.planets || []).reduce((total, planet) =>
      total + getSelectedBuildingIds(planet.id).length, 0);
    const selectedResearchCount = getSelectedResearchIds().length;
    if (!selectedCount && !selectedResearchCount) {
      alert('Seleciona pelo menos um edifício ou uma pesquisa antes de iniciar a monitorização.');
      return;
    }
    if (autoBuildTimer) clearTimeout(autoBuildTimer);
    if (accountRefreshTimer) clearTimeout(accountRefreshTimer);
    accountRefreshTimer = null;
    accountRefreshDueAt = null;
    state.autoBuild.resumeAfterNavigation = false;
    state.autoBuild.navigationTarget = null;
    state.autoBuild.manualNavigationHold = false;
    state.autoBuild.active = true;
    state.autoBuild.manualPlanetId = String(getPagePlanetId() || state.autoBuild.manualPlanetId || '');
    state.autoBuild.currentQueueId = null;
    state.autoBuild.currentResearchQueueId = null;
    state.autoBuild.nextCheckAt = null;
    reconcileAutomaticResearchQueue();
    state.autoBuild.lastMessage = 'Monitorização iniciada: verifico todas as filas em segundo plano; podes navegar livremente na janela principal.';
    save();
    render();
    runAutoBuild();
  }

  function render() {
    captureBuildingSelections();
    captureResearchSelections();
    root.style.top = `${Math.max(4, Math.min(state.position.top, window.innerHeight - 100))}px`;
    root.style.right = `${Math.max(4, Math.min(state.position.right, window.innerWidth - 100))}px`;
    root.classList.toggle('min', !!state.minimized);

    const current = getCurrentPlanet();
    const displayed = getDisplayedPlanet();
    const allPlanets = state.accountSnapshot?.planets || [];
    const next = state.queue.find(item => item.status === 'pending');
    const sent = state.queue.find(item => item.status === 'sent');
    const inProgressBuilding = (state.activeBuildingLocks || [])[0] || null;
    const queueHtml = state.queue.length ? state.queue.map((item, index) => {
      const queueStatus = item.status === 'done' ? 'Concluído'
        : item.status === 'cancelled' ? 'Cancelado'
        : item.status === 'started' ? 'Construção iniciada'
        : item.status === 'sent' ? 'Pedido enviado — a confirmar'
        : item.retryAfter && Number(item.retryAfter) > Date.now() ? 'A aguardar próxima verificação'
        : 'Pendente — disponibilidade confirmada no jogo';
      const assessmentHtml = `<div class=\"item-status ${item.status === 'started' ? 'started' : item.status === 'sent' ? 'sent' : 'wait'}\">${esc(queueStatus)}</div>`;
      return `
      <div class="item ${next && next.id === item.id ? 'current' : ''}">
        <div><div class="item-title">${index + 1}. ${esc(item.building)} — nível ${Number(item.targetLevel)}</div>
          <div class="item-meta">${esc(item.planet || 'Planeta por definir')} · ${item.status === 'done' ? 'Concluído' : item.status === 'cancelled' ? 'Cancelado — edifício retirado da seleção' : item.status === 'started' ? 'Construção iniciada' : item.status === 'sent' ? 'Clique enviado — aguarda confirmação do nível' : 'Pendente / a aguardar validação no jogo'}${Number.isInteger(item.currentLevel) ? ` · atual ${item.currentLevel}` : ''}</div></div>
        <div class="item-buttons">
          <button data-action="up" data-id="${esc(item.id)}" ${index === 0 ? 'disabled' : ''} title="Mover para cima">↑</button>
          <button data-action="down" data-id="${esc(item.id)}" ${index === state.queue.length - 1 ? 'disabled' : ''} title="Mover para baixo">↓</button>
          <button data-action="cancel-order" data-id="${esc(item.id)}" title="Anular esta ordem, removê-la da fila e desmarcar o edifício neste planeta" aria-label="Anular ${esc(item.building)} em ${esc(item.planet || 'planeta')}">×</button>
        </div>
        ${assessmentHtml}
      </div>`;
    }).join('') : '<div class="muted">A fila ainda está vazia.</div>';

    const statusClass = readStatus.startsWith('Leitura concluída') ? 'notice good'
      : (readStatus.startsWith('Não foi possível') ? 'notice error' : 'notice');
    const snapshotAge = state.accountSnapshot?.syncedAt
      ? new Date(state.accountSnapshot.syncedAt).toLocaleString('pt-PT') : 'Ainda não lido';
    const planetOptions = allPlanets.map(planet =>
      `<option value="${esc(planet.id)}" ${String(planet.id) === String(displayed?.id) ? 'selected' : ''}>${esc(planet.type === 'moon' ? 'Lua' : 'Planeta')} · ${esc(planet.name)} ${planet.coords ? `[${esc(planet.coords)}]` : ''}</option>`
    ).join('');
    const analysisHtml = state.mode === 'auto' ? `<div class=\"section\"><strong>Monitorização automática — edifícios</strong><div class=\"muted\">O gestor verifica edifícios selecionados em todos os planetas e luas a cada 45–60 segundos. Uma construção ativa por planeta.</div>${renderAutomaticSuggestions()}</div>` : '';
    const selectedResearchCount = getSelectedResearchIds().length;
    const activeResearchItem = state.researchQueue.find(item => item.status === 'sent' || item.status === 'started') || state.activeResearchLock;
    const researchTabHtml = `
      <div class=\"section\"><strong>Pesquisas globais</strong>
        <div class=\"muted\">As tecnologias são globais à conta: escolhe as que queres acompanhar. A fila respeita uma investigação de cada vez.</div>
        <div class=\"research-list\">${renderResearchChoices()}</div>
        ${state.mode === 'manual' ? '<button class=\"primary\" data-action=\"add-selected-research\">Adicionar pesquisas selecionadas à fila</button>' : (state.autoBuild?.active ? '<button data-action=\"stop-auto-build\">Parar monitorização</button>' : '<button class=\"primary\" data-action=\"prepare-and-run\">Iniciar monitorização automática</button>')}
        <div class=\"muted\">Selecionadas: ${selectedResearchCount} · Níveis conhecidos: ${Object.keys(state.accountSnapshot?.researches || {}).length}/${Object.keys(RESEARCHES).length}</div>
      </div>
      ${state.mode === 'auto' ? `<div class=\"section\"><strong>Monitorização automática — pesquisas</strong>
        <div class=\"muted\">O gestor tenta iniciar a próxima pesquisa selecionada num planeta com Laboratório de Pesquisas. O botão do jogo valida recursos e pré-requisitos. Só existe uma investigação ativa em toda a conta.</div>
        ${activeResearchItem ? `<div class=\"notice good\">Em curso: ${esc(activeResearchItem.research)} nível ${Number(activeResearchItem.targetLevel)}${activeResearchItem.sourcePlanet ? ` · ${esc(activeResearchItem.sourcePlanet)}` : ''}.</div>` : '<div class=\"muted\">Não há investigação submetida neste momento.</div>'}
        <div class=\"muted\">Monitorização integrada com a fila de edifícios.</div>
        ${state.autoBuild?.lastMessage ? `<div class=\"notice\">${esc(state.autoBuild.lastMessage)}</div>` : ''}
      </div>` : ''}
      <div class=\"section\"><div class=\"topline\"><strong>Fila de pesquisas</strong><strong>${state.researchQueue.length}</strong></div>
        <div class=\"queue\">${renderResearchQueue()}</div>
        <div class=\"muted\">As pesquisas iniciadas saem da fila; a fila mostra apenas as próximas pesquisas pendentes.</div>
      </div>`;
    const buildingTabHtml = `
      <div class=\"section\">
        <strong>Escolher edifícios e nível pretendido</strong>
        ${allPlanets.length ? `<select class=\"planet-select\" id=\"ogbqm-select-planet\">${planetOptions}</select>` : '<div class=\"muted\">Atualiza os dados para carregar os planetas.</div>'}
        ${displayed ? `<div class=\"muted\">${esc(displayed.name)} ${displayed.coords ? `· ${esc(displayed.coords)}` : ''} — seleciona os edifícios a acompanhar. No modo automático, o alvo é sempre o nível atual +1.</div>` : ''}
        <div class=\"list-head\"><span></span><span>Edifício</span><span>Atual</span><span>Subir para</span></div>
        <div class=\"building-list\" data-planet-id=\"${esc(displayed?.id || '')}\">${renderBuildingChoices(displayed)}</div>
        <button class=\"primary\" data-action=\"add-selected\" ${displayed && state.mode === 'manual' ? '' : 'disabled'} style=\"${state.mode === 'auto' ? 'display:none' : ''}\">Adicionar selecionados à fila</button>
      </div>
      ${analysisHtml}
      <div class=\"section\"><div class=\"topline\"><strong>Fila de edifícios</strong><strong>${state.queue.length}</strong></div>
        <div class=\"queue\">${queueHtml}</div>
        <div class=\"actions\"><button data-action=\"export\">Exportar filas</button><button data-action=\"reset\">Repor gestor</button></div>
      </div>`;

    root.innerHTML = `
      <div class="head" id="ogbqm-drag">
        <div><div class="brand">OGame Building Queue Manager</div><div class="muted">S181 · v${VERSION}</div></div>
        <button data-action="min" title="${state.minimized ? 'Expandir' : 'Minimizar'}">${state.minimized ? '□' : '—'}</button>
      </div>
      <div class="body">
        <div class="mode">
          <div><strong>Modo ${state.mode === 'manual' ? 'Manual' : 'Automático — execução'}</strong>
            <div class="muted">${state.mode === 'manual' ? 'Edifícios e pesquisas têm filas separadas' : 'Verifica edifícios e pesquisas a cada 45–60 segundos'}</div></div>
          <label class="switch" title="Alternar modo"><input id="ogbqm-mode" type="checkbox" ${state.mode === 'auto' ? 'checked' : ''}><span class="slider"></span></label>
        </div>

        <div class="section">
          <div class="topline"><strong>Planeta aberto: ${esc(current.name)}</strong><span class="muted">${esc(current.coords || '')}</span></div>
          <div class="topline"><span class="muted">Última leitura: ${esc(snapshotAge)}</span>
            <button data-action="read" ${readBusy ? 'disabled' : ''}>${readBusy ? 'A ler…' : 'Atualizar agora'}</button></div>
          <div class="muted">Os dados são atualizados automaticamente desde o arranque, a cada 45–60 segundos. «Atualizar agora» é apenas uma atualização imediata opcional.</div>
          ${readStatus ? `<div class="${statusClass}">${esc(readStatus)}</div>` : ''}
        </div>

        <div class="countdown-panel"><span>Próxima verificação global (edifícios + pesquisas)</span><strong id="ogbqm-countdown">${esc(getAutoCountdownText())}</strong></div>

        <div class="tabs">
          <button data-action="tab-buildings" class="${state.activeTab === 'buildings' ? 'active' : ''}">Edifícios (${state.queue.filter(item => !['done','cancelled'].includes(item.status)).length})</button>
          <button data-action="tab-research" class="${state.activeTab === 'research' ? 'active' : ''}">Pesquisas (${state.researchQueue.filter(item => !['done','cancelled'].includes(item.status)).length})</button>
        </div>
        ${state.activeTab === 'research' ? researchTabHtml : buildingTabHtml}
        <div class="footer">${state.activeTab === 'research'
          ? (activeResearchItem ? `Em curso: ${esc(activeResearchItem.research)} nível ${Number(activeResearchItem.targetLevel)}; fora da fila pendente.` : 'A fila global de pesquisas está pronta.')
          : (next ? `Próxima: ${esc(next.building)} nível ${Number(next.targetLevel)} · ${esc(next.planet || 'planeta por definir')}.` : sent ? `A aguardar confirmação: ${esc(sent.building)} nível ${Number(sent.targetLevel)} · ${esc(sent.planet || 'planeta por definir')}.` : inProgressBuilding ? `Em construção: ${esc(inProgressBuilding.building)} nível ${Number(inProgressBuilding.targetLevel)} · ${esc(inProgressBuilding.planet)}; removida da fila pendente.` : 'A fila de edifícios não tem tarefas pendentes.')}
          ${state.mode === 'auto' ? 'Monitorização em segundo plano ativa; uma construção por planeta e uma investigação global de cada vez. Navegação manual livre.' : 'Modo Manual: as ordens são apresentadas sem execução automática.'}</div>
      </div>`;
  }

  root.addEventListener('click', event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const action = button.dataset.action;
    const id = button.dataset.id;
    const index = state.queue.findIndex(item => item.id === id);

    if (action === 'read') { readAccountData().finally(() => { if (state.autoBuild?.active) scheduleNextAutoCheck('Atualização manual concluída; mantenho o ciclo global.'); else scheduleAccountRefresh(); }); return; }
    if (action === 'tab-buildings') { captureResearchSelections(); state.activeTab = 'buildings'; save(); render(); return; }
    if (action === 'tab-research') { captureBuildingSelections(); state.activeTab = 'research'; save(); render(); return; }
    if (action === 'add-selected-research') {
      captureResearchSelections();
      const ids = getSelectedResearchIds();
      if (!ids.length) return alert('Seleciona pelo menos uma pesquisa com nível conhecido.');
      let added = 0;
      for (const technologyId of ids) {
        const level = getResearchLevel(technologyId);
        if (level === null) continue;
        const duplicate = state.researchQueue.some(item => String(item.technologyId) === technologyId
          && !['done', 'cancelled'].includes(item.status));
        if (duplicate) continue;
        state.researchQueue.push({
          id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
          type: 'research', technologyId, research: RESEARCHES[technologyId].name,
          currentLevel: level, targetLevel: level + 1, status: 'pending', createdAt: new Date().toISOString()
        });
        added++;
      }
      if (!added) alert('Não foram adicionadas pesquisas novas: já existem ordens ativas para as tecnologias selecionadas.');
      save(); render(); return;
    }
    if (action === 'cancel-research') {
      const researchIndex = state.researchQueue.findIndex(item => item.id === id);
      if (researchIndex < 0) return;
      const item = state.researchQueue[researchIndex];
      const sent = item.status === 'sent' || item.status === 'started';
      state.researchSelections ||= {};
      state.researchSelections[String(item.technologyId)] = { checked: false };
      if (sent) {
        state.activeResearchLock = {
          technologyId: String(item.technologyId),
          targetLevel: Number(item.targetLevel),
          research: item.research,
          sourcePlanetId: item.sourcePlanetId || '',
          sourcePlanet: item.sourcePlanet || ''
        };
      }
      state.researchQueue.splice(researchIndex, 1);
      state.autoBuild.currentResearchQueueId = null;
      state.autoBuild.lastMessage = sent
        ? `${item.research} retirada do gestor e desmarcada. A investigação já tinha sido enviada ao jogo; para a cancelar, usa a opção de cancelar no próprio OGame.`
        : `${item.research} removida da fila e da monitorização automática.`;
      save(); render();
      if (state.autoBuild.active && !autoBuildBusy) scheduleNextAutoCheck('Pesquisa retirada; continuo a monitorizar as restantes ordens.');
      return;
    }
    if (action === 'research-up' || action === 'research-down') {
      const visible = state.researchQueue.filter(item => item.status !== 'cancelled');
      const ri = visible.findIndex(item => item.id === id);
      if (ri >= 0) {
        const targetIndex = action === 'research-up' ? ri - 1 : ri + 1;
        if (targetIndex >= 0 && targetIndex < visible.length) {
          const a = state.researchQueue.indexOf(visible[ri]);
          const b = state.researchQueue.indexOf(visible[targetIndex]);
          [state.researchQueue[a], state.researchQueue[b]] = [state.researchQueue[b], state.researchQueue[a]];
        }
      }
      save(); render(); return;
    }
    if (action === 'clear-done-research') {
      state.researchQueue = state.researchQueue.filter(item => !['done', 'cancelled'].includes(item.status));
      save(); render(); return;
    }
    if (action === 'stop-auto-build') { stopAutoBuild('Automatismo parado pelo utilizador.'); return; }
    if (action === 'prepare-and-run') {
      startAutoBuild();
      return;
    }
    if (action === 'min') state.minimized = !state.minimized;
    if (action === 'add-selected') {
      captureBuildingSelections();
      const planet = getDisplayedPlanet();
      if (!planet) return alert('Atualiza primeiro os dados dos planetas.');
      const checkedRows = [...root.querySelectorAll('.building-row')].filter(row => row.querySelector('.building-check')?.checked);
      if (!checkedRows.length) return alert('Seleciona pelo menos um edifício com o visto.');
      let added = 0;
      for (const row of checkedRows) {
        const buildingId = row.dataset.buildingId;
        const building = BUILDINGS[buildingId] || `Edifício #${buildingId}`;
        const currentLevel = asInt(row.dataset.currentLevel);
        const targetLevel = Number(row.querySelector('.target-level')?.value);
        if (!Number.isInteger(targetLevel) || targetLevel <= currentLevel) continue;
        const duplicate = hasBuildingLock(planet.id, buildingId) || state.queue.some(item => item.status !== 'done'
          && String(item.planetId) === String(planet.id)
          && String(item.buildingId) === String(buildingId)
          && Number(item.targetLevel) === targetLevel);
        if (duplicate) continue;
        state.queue.push({
          id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
          building,
          planet: planet.name,
          planetId: String(planet.id),
          buildingId: String(buildingId),
          currentLevel,
          targetLevel,
          status: 'pending',
          createdAt: new Date().toISOString()
        });
        added++;
      }
      if (!added) alert('Não foram adicionadas ordens novas. Confirma se os níveis escolhidos são superiores aos atuais e se não estão duplicados.');
    }
    if ((action === 'cancel-order' || action === 'delete') && index >= 0) {
      const item = state.queue[index];
      const alreadySent = item.status === 'sent' || item.status === 'started';

      // Em modo automático, apagar só a linha não chega: a seleção continuaria
      // ativa e reconcileAutomaticQueue voltaria a criar a mesma ordem no ciclo
      // seguinte. O X desmarca também este edifício apenas neste planeta.
      if (state.mode === 'auto' || item.autoGenerated) {
        // Primeiro sincroniza os vistos do painel, mas evita que o visto ainda
        // presente no DOM volte a ativar a monitorização durante o render().
        captureBuildingSelections();
        const visibleList = root.querySelector('.building-list');
        if (visibleList && String(visibleList.dataset.planetId || '') === String(item.planetId)) {
          const row = [...visibleList.querySelectorAll('.building-row')]
            .find(element => String(element.dataset.buildingId || '') === String(item.buildingId));
          const checkbox = row?.querySelector('.building-check');
          if (checkbox) checkbox.checked = false;
        }
        state.buildingSelections ||= {};
        const planetSelections = state.buildingSelections[String(item.planetId)] ||= {};
        const buildingSelection = planetSelections[String(item.buildingId)] ||= {};
        buildingSelection.checked = false;
      }

      if (alreadySent) addBuildingLock(item);
      if (state.autoBuild?.currentQueueId === item.id) {
        state.autoBuild.currentQueueId = null;
      }
      state.queue.splice(index, 1);
      state.autoBuild ||= clone(DEFAULTS.autoBuild);
      state.autoBuild.lastMessage = alreadySent
        ? `Ordem de ${item.building} retirada do gestor e seleção desativada em ${item.planet}. Atenção: o pedido já tinha sido enviado ao OGame; para interromper uma construção já iniciada, cancela-a também na fila do próprio jogo.`
        : `Ordem de ${item.building} anulada e removida da fila em ${item.planet}. O edifício ficou desmarcado e não será novamente colocado na fila automaticamente.`;
      save();
      render();
      if (state.autoBuild.active && !autoBuildBusy) {
        scheduleNextAutoCheck('Ordem anulada; continuo a verificar as restantes ordens.');
      }
      return;
    }
    if (action === 'up' && index > 0) [state.queue[index - 1], state.queue[index]] = [state.queue[index], state.queue[index - 1]];
    if (action === 'down' && index >= 0 && index < state.queue.length - 1) [state.queue[index + 1], state.queue[index]] = [state.queue[index], state.queue[index + 1]];
    if (action === 'clear-done') state.queue = state.queue.filter(item => !['done', 'cancelled'].includes(item.status));
    if (action === 'export') {
      const blob = new Blob([JSON.stringify({ version: VERSION, buildingQueue: state.queue, researchQueue: state.researchQueue }, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'ogame-building-and-research-queue-s181.json'; anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    if (action === 'reset' && confirm('Apagar a fila, dados lidos e definições do gestor?')) state = clone(DEFAULTS);
    save();
    render();
  });

  root.addEventListener('change', event => {
    if (event.target.matches('.research-check')) {
      captureResearchSelections();
      save();
      if (state.mode === 'auto' && state.autoBuild?.active) reconcileAutomaticResearchQueue();
      render();
      return;
    }
    if (event.target.matches('.building-check, .target-level')) {
      captureBuildingSelections();
      save();
      render();
      return;
    }
    if (event.target.id === 'ogbqm-mode') {
      state.mode = event.target.checked ? 'auto' : 'manual';
      if (state.mode === 'manual' && state.autoBuild?.active) {
        if (autoBuildTimer) clearTimeout(autoBuildTimer);
        autoBuildTimer = null;
        state.autoBuild.active = false;
        state.autoBuild.currentQueueId = null;
        state.autoBuild.currentResearchQueueId = null;
        state.autoBuild.nextCheckAt = null;
        state.autoBuild.resumeAfterNavigation = false;
        state.autoBuild.navigationTarget = null;
        state.autoBuild.manualNavigationHold = false;
        state.autoBuild.lastMessage = 'Monitorização parada ao mudar para modo Manual.';
      }
      normalizeAutoSelections();
      if (state.mode === 'auto') reconcileAutomaticResearchQueue();
      save(); render();
      if (state.mode === 'manual') scheduleAccountRefresh();
    }
    if (event.target.id === 'ogbqm-select-planet') {
      captureBuildingSelections();
      state.selectedPlanetId = event.target.value;
      save(); render();
    }
  });

  root.addEventListener('pointerdown', event => {
    const handle = event.target.closest('#ogbqm-drag');
    if (!handle || event.target.closest('button')) return;
    const rect = root.getBoundingClientRect();
    drag = { x: event.clientX, y: event.clientY, top: rect.top, right: window.innerWidth - rect.right };
    handle.setPointerCapture?.(event.pointerId);
  });
  root.addEventListener('pointermove', event => {
    if (!drag) return;
    const maxTop = Math.max(4, window.innerHeight - 50);
    state.position.top = Math.max(4, Math.min(maxTop, drag.top + event.clientY - drag.y));
    state.position.right = Math.max(4, Math.min(window.innerWidth - 100, drag.right - (event.clientX - drag.x)));
    root.style.top = `${state.position.top}px`;
    root.style.right = `${state.position.right}px`;
  });
  root.addEventListener('pointerup', () => { if (drag) { drag = null; save(); } });
  root.addEventListener('pointercancel', () => { if (drag) { drag = null; save(); } });
  window.addEventListener('resize', () => {
    state.position.top = Math.max(4, Math.min(state.position.top, window.innerHeight - 100));
    state.position.right = Math.max(4, Math.min(state.position.right, window.innerWidth - 100));
    save(); render();
  });

  // Ao mudar de planeta no jogo, guarda as seleções do planeta anterior,
  // muda o contexto do painel e atualiza níveis/recursos automaticamente.
  const planetMetaSelector = 'meta[name="ogame-planet-id"], meta[name="ogame-planet-type"]';
  const initialPagePlanetId = String(getPagePlanetId());
  const previousObservedPagePlanetId = String(state.lastObservedPagePlanetId || '');
  // Compatibilidade com versões anteriores: elimina o bloqueio de navegação,
  // pois a versão atual executa ordens fora da janela principal.
  state.autoBuild.manualNavigationHold = false;
  state.autoBuild.resumeAfterNavigation = false;
  state.autoBuild.navigationTarget = null;
  if (initialPagePlanetId && previousObservedPagePlanetId !== initialPagePlanetId) {
    state.selectedPlanetId = initialPagePlanetId;
    state.lastObservedPagePlanetId = initialPagePlanetId;
    save();
  }
  let observedPlanetKey = `${getPagePlanetId()}|${getPagePlanetType()}`;

  function syncCurrentPlanetContext() {
    const nextKey = `${getPagePlanetId()}|${getPagePlanetType()}`;
    if (!nextKey.split('|')[0] || nextKey === observedPlanetKey) return;

    captureBuildingSelections();
    observedPlanetKey = nextKey;
    const activeId = String(getPagePlanetId());
    // A mudança de planeta é sempre navegação manual do utilizador; não pausa
    // a monitorização, porque as ordens são executadas no iframe oculto.
    if (activeId) {
      state.selectedPlanetId = activeId;
      state.lastObservedPagePlanetId = activeId;
      if (!state.autoBuild?.active) rememberManualPlanetId(activeId);
    }
    save();
    render();

    // accountInfo devolve todos os planetas; a atualização não depende de
    // clicar em "Atualizar dados". Se já houver leitura em curso, ela própria
    // já está a obter a fotografia completa da conta.
    if (!readBusy && !state.autoBuild?.active) readAccountData({ silent: true }).finally(() => scheduleAccountRefresh());
  }

  const pageObserver = new MutationObserver(() => syncCurrentPlanetContext());
  pageObserver.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['content']
  });
  window.addEventListener('popstate', () => {
    rememberManualPlanetId(getPagePlanetId());
    syncCurrentPlanetContext();
  });
  window.addEventListener('hashchange', () => {
    rememberManualPlanetId(getPagePlanetId());
    syncCurrentPlanetContext();
  });
  // Algumas mudanças de planeta são feitas por navegação interna do OGame,
  // sem evento popstate nem alteração observável do <head>.
  const planetContextPoll = window.setInterval(syncCurrentPlanetContext, 1200);

  // Se o separador já estiver na página de Pesquisas, recolhe os níveis
  // disponíveis no DOM e guarda-os como complemento do accountInfo.
  if (new URLSearchParams(location.search).get('component') === 'research') {
    const domResearches = readResearchLevelsFromDom();
    if (Object.keys(domResearches).length) {
      state.accountSnapshot ||= { syncedAt: new Date().toISOString(), planets: [], researches: {} };
      state.accountSnapshot.researches ||= {};
      for (const [id, level] of Object.entries(domResearches)) {
        if (state.accountSnapshot.researches[id] === undefined) state.accountSnapshot.researches[id] = level;
      }
      save();
    }
  }

  render();
  // Atualiza apenas o texto do contador; não volta a renderizar o painel nem
  // interfere com as caixas de seleção que o utilizador está a editar.
  const countdownUiTimer = window.setInterval(updateCountdownDisplay, 1000);
  if (state.autoBuild?.active && state.mode === 'auto') {
    if (autoBuildTimer) clearTimeout(autoBuildTimer);
    autoBuildTimer = null;
    const dueAt = Number(state.autoBuild.nextCheckAt);
    if (Number.isFinite(dueAt) && dueAt > Date.now()) {
      autoBuildTimer = setTimeout(() => {
        autoBuildTimer = null;
        state.autoBuild.nextCheckAt = null;
        runAutoBuild();
      }, dueAt - Date.now());
    } else {
      setTimeout(runAutoBuild, 1200);
    }
  } else {
    // Uma leitura inicial imediata; a partir daí, um único refresh aleatório
    // entre 45 e 60 segundos, também refletido no contador comum.
    readAccountData({ silent: Boolean(state.accountSnapshot) }).finally(() => scheduleAccountRefresh());
  }
})();
